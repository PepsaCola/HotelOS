import { NavLink } from "react-router-dom";
import { primaryNav, secondaryNav } from "@/lib/nav";
import { CloseIcon, LogoutIcon, PlusIcon } from "@/components/ui/icons";

interface SidebarProps {
  /** Whether the mobile drawer is open. */
  open: boolean;
  /** Called when navigation happens or the backdrop is tapped (mobile). */
  onClose: () => void;
}

function navItemClasses(isActive: boolean) {
  return [
    "flex items-center gap-3 rounded-[10px] px-3 py-2.5 text-sm leading-4 text-left transition-colors",
    isActive ? "bg-chip-active text-blue font-medium" : "text-ink hover:bg-surface-muted",
  ].join(" ");
}

export default function Sidebar({ open, onClose }: SidebarProps) {
  return (
    <>
      {/* Mobile backdrop */}
      <div
        className={`fixed inset-0 z-30 bg-black/30 transition-opacity lg:hidden ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={onClose}
        aria-hidden="true"
      />

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[250px] flex-col border-r border-page-border bg-white transition-transform lg:static lg:z-auto lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Brand */}
        <div className="flex h-[60px] items-center justify-between border-b border-page-border px-4">
          <div className="flex items-center gap-2">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-b from-[#6a6aff] to-[#4949f3] text-sm font-bold text-white">
              H
            </span>
            <span className="font-brand text-[22px] leading-none text-ink">
              Hotel<span className="text-[#a1a1ae]">OS</span>
            </span>
          </div>
          <button
            type="button"
            className="grid h-8 w-8 place-items-center rounded-md text-muted hover:bg-surface-muted lg:hidden"
            onClick={onClose}
            aria-label="Close navigation"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex flex-1 flex-col justify-between gap-5 overflow-y-auto p-4">
          <div className="flex flex-col gap-4">
            <NavLink
              to="/create-po"
              onClick={onClose}
              className="flex h-10 items-center gap-3 rounded-[10px] bg-gradient-to-b from-[#6a6aff] to-[#4949f3] px-3 text-sm font-semibold text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,0.2)]"
            >
              <PlusIcon className="h-[18px] w-[18px]" />
              <span>New Purchase Order</span>
            </NavLink>

            <nav className="flex flex-col gap-px" aria-label="Primary">
              {primaryNav.map(({ path, label, icon: Icon }) => (
                <NavLink
                  key={path}
                  to={path}
                  onClick={onClose}
                  className={({ isActive }) => navItemClasses(isActive)}
                >
                  <span className="grid h-[18px] w-[18px] flex-none place-items-center">
                    <Icon className="h-[18px] w-[18px]" />
                  </span>
                  <span>{label}</span>
                </NavLink>
              ))}
            </nav>
          </div>

          <div className="flex flex-col gap-3">
            <div className="h-px w-full bg-page-border" />
            <nav className="flex flex-col gap-px" aria-label="Settings">
              {secondaryNav.map(({ path, label, icon: Icon }) => (
                <NavLink
                  key={path}
                  to={path}
                  onClick={onClose}
                  className={({ isActive }) => navItemClasses(isActive)}
                >
                  <span className="grid h-[18px] w-[18px] flex-none place-items-center">
                    <Icon className="h-[18px] w-[18px]" />
                  </span>
                  <span>{label}</span>
                </NavLink>
              ))}
              <button type="button" className={navItemClasses(false)}>
                <span className="grid h-[18px] w-[18px] flex-none place-items-center">
                  <LogoutIcon className="h-[18px] w-[18px]" />
                </span>
                <span>Log Out</span>
              </button>
            </nav>
          </div>
        </div>
      </aside>
    </>
  );
}
