import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import { findNavByPath } from "@/lib/nav";

export default function AppShell() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const location = useLocation();

  // Close the mobile drawer whenever the route changes.
  useEffect(() => {
    setMobileNavOpen(false);
  }, [location.pathname]);

  const activeNav = findNavByPath(location.pathname);
  const crumb = activeNav?.title ?? "HotelOS";

  return (
    <div className="flex min-h-screen bg-white">
      <Sidebar open={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar crumb={crumb} onOpenMenu={() => setMobileNavOpen(true)} />
        <main className="min-w-0 flex-1 px-4 py-4 lg:px-7 lg:pb-20">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
