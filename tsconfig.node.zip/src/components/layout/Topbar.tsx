import { BellIcon, HelpIcon, MenuIcon, SearchIcon } from "@/components/ui/icons";

interface TopbarProps {
  crumb: string;
  onOpenMenu: () => void;
}

export default function Topbar({ crumb, onOpenMenu }: TopbarProps) {
  return (
    <header className="flex h-[60px] flex-none items-center gap-4 border-b border-page-border px-4 lg:px-7">
      <button
        type="button"
        className="grid h-9 w-9 flex-none place-items-center rounded-md text-ink hover:bg-surface-muted lg:hidden"
        onClick={onOpenMenu}
        aria-label="Open navigation"
      >
        <MenuIcon className="h-5 w-5" />
      </button>

      <div className="hidden text-sm font-medium text-muted sm:block">{crumb}</div>

      <div className="mx-auto flex h-9 w-full max-w-[400px] items-center gap-2 rounded-full border border-page-border bg-white px-3 shadow-soft">
        <SearchIcon className="h-5 w-5 flex-none text-muted" />
        <input
          type="search"
          placeholder="Search PO #, vendor, department…"
          className="w-full min-w-0 bg-transparent text-sm text-ink outline-none placeholder:text-muted"
        />
      </div>

      <div className="flex flex-none items-center gap-3">
        <button
          type="button"
          className="hidden h-9 items-center gap-2 rounded-md px-3 text-sm font-medium text-ink hover:bg-surface-muted md:flex"
        >
          <HelpIcon className="h-5 w-5" />
          <span>Help</span>
        </button>
        <button
          type="button"
          className="grid h-9 w-9 place-items-center rounded-full border border-page-border text-ink hover:bg-surface-muted"
          aria-label="Notifications"
        >
          <BellIcon className="h-5 w-5" />
        </button>
        <div className="grid h-9 w-9 place-items-center rounded-full bg-ink text-base font-medium text-white">
          DP
        </div>
      </div>
    </header>
  );
}
