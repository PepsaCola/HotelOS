interface SegmentedOption<T extends string> {
  value: T;
  label: string;
}

interface SegmentedControlProps<T extends string> {
  options: ReadonlyArray<SegmentedOption<T>>;
  value: T;
  onChange: (value: T) => void;
  "aria-label"?: string;
}

/** Pill-style toggle group used across dashboard cards and other modules. */
export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  "aria-label": ariaLabel,
}: SegmentedControlProps<T>) {
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className="inline-flex rounded-lg border border-hair-2 bg-[#fafaf6] p-0.5"
    >
      {options.map((option) => {
        const isActive = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(option.value)}
            className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
              isActive
                ? "bg-white text-ink-900 shadow-[0_1px_2px_rgba(0,0,0,0.05)]"
                : "text-muted-strong hover:text-ink-900"
            }`}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
