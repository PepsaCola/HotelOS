export type InvoiceStatus = "processed" | "ocr" | "over-budget" | "no-match" | "review";
export type InvoiceStatusFilter = "all" | InvoiceStatus;

export type InvoiceDept = "all" | "Rooms" | "F&B" | "A&G" | "IT" | "S&M" | "R&M";
export type AmountRange = "any" | "under-1k" | "1k-3k" | "over-3k";
export type SortKey = "updated" | "received" | "highest" | "lowest";

export interface InvoiceMatch {
    poMatched: boolean;
    linesMatched: number;
    linesTotal: number;
}

export interface Invoice {
    id: string;
    vendor: string;
    dept: InvoiceDept;
    receivedDate: string;
    receivedTimestamp: number;
    amount: number;
    taxIncluded: boolean;
    poRef: string | null;
    match: InvoiceMatch | null;
    status: InvoiceStatus;
    updatedAt: string;
    updatedTimestamp: number;
}

export interface InvoicesKpi {
    receivedCount: number;
    receivedValue: number;
    intakeCount: number;
    intakeExtracting: number;
    intakeQueued: number;
    awaitingMatchCount: number;
    awaitingAttentionCount: number;
    exceptionsCount: number;
    exceptionsValue: number;
}

export interface InvoicesData {
    invoices: Invoice[];
    kpi: InvoicesKpi;
    tabCounts: Record<InvoiceStatusFilter, number>;
    month: string;
    lastSync: string;
}