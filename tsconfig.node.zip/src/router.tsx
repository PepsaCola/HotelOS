// src/router.tsx
import { createBrowserRouter, Navigate } from "react-router-dom";
import AppShell from "@/components/layout/AppShell";
import PagePlaceholder from "@/components/ui/PagePlaceholder";
import { allNav } from "@/lib/nav";
import DashboardPage from "@/modules/dashboard/DashboardPage";
import POLogPage from "@/modules/po-log/POLogPage.tsx";
import ApprovalsPage from "@/modules/approvals/ApprovalsPage";
import ReceivingPage from "@/modules/receiving/ReceivingPage.tsx";
import InvoicesPage from "@/modules/invoices/InvoicesPage.tsx"; // ДОДАНО ІМПОРТ

const createPoMeta = {
  title: "Create Purchase Order",
  subtitle: "Start a new order draft with a clean handoff into the approval flow.",
};

/** Modules that have been migrated render their real page; the rest fall back to a placeholder. */
const moduleElements: Record<string, JSX.Element> = {
  "/dashboard": <DashboardPage />,
  "/po-log": <POLogPage />,
  "/approval": <ApprovalsPage />,
  "/receiving": <ReceivingPage />,
  "/invoices": <InvoicesPage />,
};

export const router = createBrowserRouter([
  {
    path: "/",
    element: <AppShell />,
    children: [
      { index: true, element: <Navigate to="/dashboard" replace /> },
      {
        path: "create-po",
        element: <PagePlaceholder title={createPoMeta.title} subtitle={createPoMeta.subtitle} />,
      },
      ...allNav.map((item) => ({
        path: item.path.replace(/^\//, ""),
        element: moduleElements[item.path] ?? (
            <PagePlaceholder title={item.title} subtitle={item.subtitle} />
        ),
      })),
      { path: "*", element: <Navigate to="/dashboard" replace /> },
    ],
  },
], {
  future: {
    v7_relativeSplatPath: true,
  },
});