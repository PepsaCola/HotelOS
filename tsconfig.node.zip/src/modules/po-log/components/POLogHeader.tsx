import { useNavigate } from "react-router-dom";
import { FilterIcon, DownloadIcon, PlusIcon, ProfitswordIcon } from "@/components/ui/icons";

interface POLogHeaderProps {
  subtitle: string;
  onOpenDisplayOptions: () => void;
}

export function POLogHeader({ subtitle, onOpenDisplayOptions }: POLogHeaderProps) {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <h1 className="text-[28px] font-bold tracking-tight text-ink-900">Purchase Order Log</h1>
        <p className="mt-1 text-[13.5px] text-muted-strong">{subtitle}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={onOpenDisplayOptions}
          className="inline-flex h-9 items-center gap-2 rounded-[9px] px-3.5 text-[13.5px] font-medium text-ink-700 hover:bg-surface-chip"
        >
          <ProfitswordIcon className="h-[15px] w-[15px]" />
          Display
        </button>
        <button className="inline-flex h-9 items-center gap-2 rounded-[9px] px-3.5 text-[13.5px] font-medium text-ink-700 hover:bg-surface-chip">
          <FilterIcon className="h-[15px] w-[15px]" />
          Advanced filter
        </button>
        <button className="inline-flex h-9 items-center gap-2 rounded-[9px] border border-hair-2 bg-white px-3.5 text-[13.5px] font-medium text-ink-900 hover:bg-surface-soft">
          <DownloadIcon className="h-[15px] w-[15px]" />
          Export
        </button>
        <button
          type="button"
          onClick={() => navigate("/create-po")}
          className="inline-flex h-9 items-center gap-2 rounded-[9px] border border-ink-900 bg-ink-900 px-3.5 text-[13.5px] font-medium text-white hover:bg-black"
        >
          <PlusIcon className="h-[15px] w-[15px]" />
          New Purchase Order
        </button>
      </div>
    </div>
  );
}
