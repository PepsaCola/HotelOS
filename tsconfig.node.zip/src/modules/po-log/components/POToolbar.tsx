import type { PODeptId, POStatus, PODepartment, StatusMeta } from "@/types/poLog";
import { CalendarIcon } from "@/components/ui/icons";
import { fmtCompact } from "@/lib/money";

interface POToolbarProps {
  departments: Record<PODeptId, PODepartment>;
  statusMeta: Record<POStatus, StatusMeta>;
  deptFilter: PODeptId | "all";
  setDeptFilter: (dept: PODeptId | "all") => void;
  statusFilter: POStatus | "all";
  setStatusFilter: (status: POStatus | "all") => void;
  totalCount: number;
  spentToDate: number;
  deptCounts: Partial<Record<PODeptId, number>>;
  deptTotals: Partial<Record<PODeptId, number>>;
}

export function POToolbar({
  departments,
  statusMeta,
  deptFilter,
  setDeptFilter,
  statusFilter,
  setStatusFilter,
  totalCount,
  spentToDate,
  deptCounts,
  deptTotals,
}: POToolbarProps) {
  const orderedDepts = Object.keys(departments) as PODeptId[];
  const spent = fmtCompact(spentToDate);

  return (
    <div className="flex flex-wrap items-center gap-2.5 rounded-t-[14px] border border-b-0 border-hair-2 bg-white p-3.5">
      <button className="inline-flex items-center gap-2 rounded-lg border border-hair-2 bg-surface-soft px-2.5 py-[7px] text-[13px] font-medium hover:bg-[#f0f0ef]">
        <CalendarIcon className="h-3.5 w-3.5 text-muted-strong" />
        April 2026
      </button>

      <div className="flex flex-wrap gap-1.5">
        <Chip active={deptFilter === "all"} onClick={() => setDeptFilter("all")}>
          All{" "}
          <span className={deptFilter === "all" ? "text-white/65" : "text-[#9aa0a8]"}>
            <b className={deptFilter === "all" ? "text-white" : "text-ink-700"}>{totalCount}</b> · {spent.whole}
            {spent.unit}
          </span>
        </Chip>
        {orderedDepts.map((d) => {
          const dept = departments[d];
          const total = fmtCompact(deptTotals[d] ?? 0);
          const active = deptFilter === d;
          return (
            <Chip key={d} active={active} onClick={() => setDeptFilter(active ? "all" : d)}>
              <span className="h-[7px] w-[7px] rounded-full" style={{ background: dept.color }} />
              {dept.name}
              <span className={active ? "text-white/65" : "text-[#9aa0a8]"}>
                <b className={active ? "text-white" : "text-ink-700"}>{deptCounts[d] ?? 0}</b> · {total.whole}
                {total.unit}
              </span>
            </Chip>
          );
        })}
      </div>

      <div className="flex-1" />

      <div className="relative">
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as POStatus | "all")}
          className="h-[34px] cursor-pointer appearance-none rounded-lg border border-hair-2 bg-white pl-2.5 pr-8 text-[13px] text-ink-700"
        >
          <option value="all">All statuses</option>
          {(Object.entries(statusMeta) as [POStatus, StatusMeta][]).map(([key, meta]) => (
            <option key={key} value={key}>
              {meta.label}
            </option>
          ))}
        </select>
        <svg
          viewBox="0 0 10 6"
          aria-hidden="true"
          className="pointer-events-none absolute right-2.5 top-1/2 h-1.5 w-2.5 -translate-y-1/2 fill-muted-strong"
        >
          <path d="M0 0h10L5 6z" />
        </svg>
      </div>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-[9px] border px-2.5 py-[7px] text-[12.5px] font-medium transition-colors ${
        active ? "border-[#0c1320] bg-[#0c1320] text-white" : "border-transparent bg-surface-muted text-ink-700 hover:bg-surface-chip"
      }`}
    >
      {children}
    </button>
  );
}
