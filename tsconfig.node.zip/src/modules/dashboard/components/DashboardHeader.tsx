import type { DashboardMeta } from "@/types/dashboard";

interface DashboardHeaderProps {
  meta: DashboardMeta;
}

export function DashboardHeader({ meta }: DashboardHeaderProps) {
  return (
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
      <div>
        <h1 className="text-2xl font-bold leading-tight tracking-tight text-ink-900">Dashboard</h1>
        <p className="mt-1 text-[12.5px] text-muted-strong">
          Overview for <b className="font-semibold text-ink-700">{meta.hotel}</b> · period closes in{" "}
          <b className="font-semibold text-ink-700">{meta.daysToClose} days</b> · last sync from M3{" "}
          <b className="font-semibold text-ink-700">{meta.lastSync}</b>
        </p>
      </div>
      <div className="flex flex-wrap items-center gap-2.5">
        <button
          type="button"
          className="inline-flex items-center gap-2 rounded-[9px] border border-hair-2 bg-white px-3.5 py-2 text-[13.5px] font-semibold text-ink-900 hover:bg-surface-soft"
        >
          <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" className="h-[15px] w-[15px]">
            <rect x="4" y="5" width="16" height="15" rx="3" stroke="currentColor" strokeWidth="1.6" />
            <path d="M8 3.75V7M16 3.75V7M4 9.5H20" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
          {meta.periodLabel}
        </button>
        <button
          type="button"
          className="inline-flex items-center gap-2 rounded-[9px] border border-ink-900 bg-ink-900 px-3.5 py-2 text-[13.5px] font-semibold text-white hover:bg-black"
        >
          <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" className="h-[15px] w-[15px]">
            <path d="M12 4v11m0 0l-4-4m4 4l4-4M5 20h14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Export Report
        </button>
      </div>
    </div>
  );
}
