import { ChevronLeftIcon } from "@/components/ui/icons";
import { formatMoney } from "@/lib/money";
import type { PurchaseOrder } from "@/types/receiving";
import { calcPoTotals, lineProgress } from "../lib/po";
import { STATUS_META } from "../lib/queue";
import { DocIcon } from "./icons";

interface DetailHeaderProps {
    po: PurchaseOrder;
    property: string;
    onBack: () => void;
}

const BADGE_CLASS: Record<string, string> = {
    good:    "bg-good-bg text-good",
    warn:    "bg-warn-bg text-warn",
    crit:    "bg-crit-bg text-crit",
    indigo:  "bg-accent-soft text-accent-ink",
    neutral: "bg-surface-chip text-ink-700",
};

const BAR_SEGMENT: Record<string, string> = {
    received: "linear-gradient(90deg,#76e2a2,#34a86b)",
    partial:  "linear-gradient(90deg,#f5c26b,#e8920a)",
};

export function DetailHeader({ po, property, onBack }: DetailHeaderProps) {
    const totals = calcPoTotals(po.lines);
    const prog   = lineProgress(po);
    const meta   = STATUS_META[po.status];
    const receivedPct = prog.totalLines > 0
        ? Math.round((prog.receivedLines / prog.totalLines) * 100)
        : 0;
    const partialPct = prog.pct - receivedPct > 0 ? prog.pct - receivedPct : 0;

    return (
        <div className="mb-5">
            {/* Title row */}
            <div className="mb-4 flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                <div className="flex items-start gap-3">
                    <button
                        type="button"
                        onClick={onBack}
                        className="mt-0.5 grid h-[38px] w-[38px] flex-shrink-0 place-items-center rounded-[9px] border border-hair-2 bg-white text-ink-700 hover:bg-surface-soft"
                    >
                        <ChevronLeftIcon className="h-4 w-4" />
                    </button>
                    <div>
                        <div className="mb-1 flex flex-wrap items-center gap-2 text-[12.5px] text-muted-strong">
                            <span>{po.vendor} · {po.dept}</span>
                            <span
                                className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold ${BADGE_CLASS[meta.tone]}`}
                            >
                <span className="h-[5px] w-[5px] rounded-full bg-current" />
                                {prog.overReceived ? "Over-received" : meta.label === "Awaiting" ? "Partially Received" : meta.label}
              </span>
                        </div>
                        <h2 className="font-mono text-[18px] font-bold tracking-tight text-ink-900">{po.id}</h2>
                        <p className="mt-0.5 text-[13.5px] text-muted-strong">{po.vendorSub}</p>
                    </div>
                </div>
                <button
                    type="button"
                    className="inline-flex h-9 shrink-0 items-center gap-2 rounded-[9px] border border-hair-2 bg-white px-3.5 text-[13.5px] font-medium text-ink-900 hover:bg-surface-soft"
                >
                    <DocIcon />
                    View PO Form
                </button>
            </div>

            {/* Summary grid */}
            <div className="overflow-hidden rounded-[14px] border border-hair-2 bg-white">
                <div className="grid grid-cols-2 divide-x divide-hair min-[900px]:grid-cols-5">
                    <SummaryCell label="Billed To">
                        <span className="font-semibold">{property}</span>
                        {po.billedContact && <span className="mt-0.5 block text-xs text-muted">{po.billedContact}</span>}
                    </SummaryCell>
                    <SummaryCell label="Vendor">
                        <span className="font-semibold">{po.vendor}</span>
                        <span className="mt-0.5 block text-xs text-muted">{po.vendorSub}</span>
                    </SummaryCell>
                    <SummaryCell label="Account Number">
                        <span className="font-semibold">{po.accountNumber ?? "—"}</span>
                    </SummaryCell>
                    <SummaryCell label="Date">
                        <span className="font-semibold">{po.poDate}</span>
                        <span className="mt-0.5 block text-xs text-muted">
              Due {po.expected}{po.terms ? ` · ${po.terms}` : ""}
            </span>
                    </SummaryCell>
                    <SummaryCell label="Total" last>
            <span className="text-[20px] font-bold tracking-tight text-ink-900" style={{ fontVariantNumeric: "tabular-nums" }}>
              {formatMoney(totals.total)}
            </span>
                        <span className="mt-0.5 block text-xs text-muted">
              Shipping {formatMoney(totals.shipping)} · Tax {formatMoney(totals.tax)}
            </span>
                    </SummaryCell>
                </div>

                {/* Progress strip */}
                <div className="border-t border-hair bg-surface-soft px-4 py-3">
                    <div className="flex items-center gap-3">
            <span className="min-w-[110px] text-[11.5px] font-semibold uppercase tracking-[0.05em] text-muted-strong">
              Line Progress
            </span>
                        <div className="relative flex-1 overflow-hidden rounded-full" style={{ height: 8, background: "#ecedf0" }}>
                            <div
                                className="absolute inset-y-0 left-0 rounded-full"
                                style={{ width: `${receivedPct}%`, background: BAR_SEGMENT.received }}
                            />
                            <div
                                className="absolute inset-y-0 rounded-full"
                                style={{ left: `${receivedPct}%`, width: `${partialPct}%`, background: BAR_SEGMENT.partial }}
                            />
                        </div>
                        <span className="min-w-[110px] text-right text-[13px] font-semibold tabular-nums text-ink-700">
              {prog.receivedLines} / {prog.totalLines} lines · {prog.pct}%
            </span>
                    </div>
                </div>
            </div>
        </div>
    );
}

function SummaryCell({ label, children, last }: { label: string; children: React.ReactNode; last?: boolean }) {
    return (
        <div className={`px-4 py-3.5 ${last ? "" : "border-b border-hair min-[900px]:border-b-0"}`}>
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-strong">{label}</div>
            <div className="text-[14px] text-ink-900">{children}</div>
        </div>
    );
}