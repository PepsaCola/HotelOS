import type { ReceivingEvent } from "@/types/receiving";
import { formatMoney } from "@/lib/money";
import { InvoiceIcon, NoteLinesIcon } from "./icons";

interface DetailTimelineProps {
    events: ReceivingEvent[];
}

export default function DetailTimeline({ events }: DetailTimelineProps) {
    if (events.length === 0) {
        return (
            <div className="rounded-[14px] border border-hair-2 bg-white px-6 py-12 text-center text-[13px] text-muted-strong">
                No invoices recorded yet.
            </div>
        );
    }

    return (
        <div>
            <div className="mb-3 flex items-center gap-2.5 text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-strong">
                <span>Invoices Timeline · newest first</span>
                <div className="h-px flex-1 bg-hair" />
            </div>

            <div className="relative flex flex-col gap-3.5 pl-6">
                {/* vertical line */}
                <div className="absolute bottom-3.5 left-0 top-3.5 w-px bg-hair-2" />

                {events.map((event, idx) => {
                    const isLast = idx === events.length - 1;
                    const isPartial = event.type === "partial";

                    return (
                        <div key={event.id} className="relative overflow-hidden rounded-[14px] border border-hair-2 bg-white">
                            {/* timeline dot */}
                            <div
                                className="absolute -left-[22px] top-[30px] h-2.5 w-2.5 rounded-full border-2 border-[#f6f6f4]"
                                style={{ background: isLast ? "var(--color-muted-strong)" : "var(--color-accent)" }}
                            />

                            {/* Event head */}
                            <div className="grid items-center gap-3.5 border-b border-hair px-4 py-3.5" style={{ gridTemplateColumns: "44px 1fr auto" }}>
                                <div className={`grid h-11 w-11 place-items-center rounded-xl ${isPartial ? "bg-warn-bg text-warn" : "bg-good-bg text-good"}`}>
                                    <InvoiceIcon />
                                </div>

                                <div>
                                    <h3 className="text-[15px] font-bold tracking-tight text-ink-900">
                                        Invoice {event.invoiceId}
                                    </h3>
                                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[12.5px] text-muted-strong">
                    <span>
                      <b className="font-semibold text-ink-700">{event.date}</b>
                    </span>
                                        <span className="text-muted">·</span>
                                        <span>
                      Updated by <b className="font-semibold text-ink-700">{event.updatedBy}</b>
                    </span>
                                        <span className="text-muted">·</span>
                                        <span>{isPartial ? "Partial PO fulfillment" : "Final PO completion"}</span>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <button
                                        type="button"
                                        className="h-7 rounded-lg px-2.5 text-[12.5px] font-medium text-ink-700 hover:bg-surface-chip"
                                    >
                                        Add Note
                                    </button>
                                    <button
                                        type="button"
                                        className="h-7 rounded-lg border border-hair-2 bg-white px-2.5 text-[12.5px] font-medium text-ink-900 hover:bg-surface-soft"
                                    >
                                        View Invoice
                                    </button>
                                </div>
                            </div>

                            {/* Lines table */}
                            <div className="overflow-x-auto">
                                <table className="w-full min-w-[500px] border-collapse text-sm">
                                    <thead>
                                    <tr>
                                        {["Qty", "Unit", "Description", "Unit Price", "Amount"].map((h, i) => (
                                            <th
                                                key={h}
                                                className={`border-b border-hair-2 bg-surface-soft px-3.5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-muted-strong ${i === 0 || i >= 3 ? "text-right" : "text-left"}`}
                                            >
                                                {h}
                                            </th>
                                        ))}
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {event.lines.map((line) => (
                                        <tr key={line.id} className="border-b border-hair last:border-0">
                                            <td className="px-3.5 py-3 text-right tabular-nums text-ink-700">{line.qty}</td>
                                            <td className="px-3.5 py-3 font-medium text-ink-900">{line.unit}</td>
                                            <td className="max-w-[320px] truncate px-3.5 py-3 font-medium text-ink-900">{line.description}</td>
                                            <td className="px-3.5 py-3 text-right tabular-nums text-ink-700">{formatMoney(line.unitPrice)}</td>
                                            <td className="px-3.5 py-3 text-right font-semibold tabular-nums text-ink-900">{formatMoney(line.amount)}</td>
                                        </tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>

                            {/* Footer: note + totals */}
                            <div className="grid gap-5 border-t border-hair p-4 min-[700px]:grid-cols-[1fr_auto]">
                                {event.note && (
                                    <div className="flex items-start gap-2 text-[12.5px] text-ink-700">
                                        <NoteLinesIcon className="mt-0.5 shrink-0 text-muted-strong" />
                                        <div>
                                            <span className="mr-1 font-semibold text-muted-strong">Note:</span>
                                            {event.note}
                                        </div>
                                    </div>
                                )}

                                <div className="w-full min-[700px]:w-[320px]">
                                    {[
                                        ["Subtotal:", event.subtotal],
                                        ["Shipping:", event.shipping],
                                        ["Tax:", event.tax],
                                    ].map(([label, val]) => (
                                        <div key={label as string} className="flex items-baseline justify-between gap-4 py-1">
                                            <span className="text-[14px] text-ink-700">{label}</span>
                                            <span className="text-[14px] font-bold tabular-nums text-ink-900">{formatMoney(val as number)}</span>
                                        </div>
                                    ))}
                                    <div className="mt-2.5 flex items-baseline justify-between gap-4 border-t-2 border-[#2f2b45] pt-3">
                                        <span className="text-[18px] font-semibold text-ink-900">Total</span>
                                        <span className="text-[18px] font-bold tracking-tight tabular-nums text-ink-900">{formatMoney(event.total)}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}