import { CalendarIcon } from "@/components/ui/icons";
import type { ReceivingDept } from "@/types/receiving";
import type { SortKey } from "../lib/queue";
import { SORT_OPTIONS } from "../lib/queue";

interface ReceivingToolbarProps {
    month: string;
    deptFilter: ReceivingDept;
    setDeptFilter: (value: ReceivingDept) => void;
    sort: SortKey;
    setSort: (value: SortKey) => void;
}

interface DeptChip {
    id: ReceivingDept;
    label: string;
    color?: string;
}

const DEPT_CHIPS: DeptChip[] = [
    { id: "all",   label: "All" },
    { id: "Rooms", label: "Rooms", color: "#4a78f0" },
    { id: "F&B",   label: "F&B",   color: "#e88a3c" },
    { id: "A&G",   label: "A&G",   color: "#7a6df0" },
    { id: "IT",    label: "IT",    color: "#119da4" },
    { id: "S&M",   label: "S&M",   color: "#c7458a" },
    { id: "R&M",   label: "R&M",   color: "#38a169" },
];

export function ReceivingToolbar({ month, deptFilter, setDeptFilter, sort, setSort }: ReceivingToolbarProps) {
    return (
        <div className="flex flex-wrap items-center gap-2.5 border-b border-hair-2 bg-white px-3.5 py-3">
            <button
                type="button"
                className="inline-flex items-center gap-2 rounded-lg border border-hair-2 bg-surface-soft px-2.5 py-[7px] text-[13px] font-medium text-ink-700 hover:bg-surface-muted"
            >
                <CalendarIcon className="h-3.5 w-3.5" />
                {month}
            </button>

            <div className="flex flex-wrap gap-1.5">
                {DEPT_CHIPS.map((chip) => {
                    const active = deptFilter === chip.id;
                    return (
                        <button
                            key={chip.id}
                            type="button"
                            onClick={() => setDeptFilter(chip.id)}
                            className={`inline-flex items-center gap-1.5 rounded-[9px] border px-2.5 py-[7px] text-[12.5px] font-medium transition-colors ${
                                active
                                    ? "border-hair-2 bg-white text-ink-900 shadow-[0_1px_2px_rgba(0,0,0,0.04)]"
                                    : "border-transparent bg-surface-soft text-ink-700 hover:bg-surface-chip"
                            }`}
                        >
                            {chip.color && (
                                <span className="h-[7px] w-[7px] rounded-full" style={{ background: chip.color }} />
                            )}
                            {chip.label}
                        </button>
                    );
                })}
            </div>

            <div className="flex-1" />

            <Select value={sort} onChange={(v) => setSort(v as SortKey)}>
                {SORT_OPTIONS.map((opt) => (
                    <option key={opt.key} value={opt.key}>
                        {opt.label}
                    </option>
                ))}
            </Select>
        </div>
    );
}

function Select({
                    value,
                    onChange,
                    children,
                }: {
    value: string;
    onChange: (v: string) => void;
    children: React.ReactNode;
}) {
    return (
        <div className="relative">
            <select
                value={value}
                onChange={(e) => onChange(e.target.value)}
                className="h-[34px] cursor-pointer appearance-none rounded-lg border border-hair-2 bg-white pl-3 pr-8 text-[13px] text-ink-700"
            >
                {children}
            </select>
            <svg
                viewBox="0 0 10 6"
                aria-hidden="true"
                className="pointer-events-none absolute right-2.5 top-1/2 h-1.5 w-2.5 -translate-y-1/2 fill-muted-strong"
            >
                <path d="M0 0h10L5 6z" />
            </svg>
        </div>
    );
}