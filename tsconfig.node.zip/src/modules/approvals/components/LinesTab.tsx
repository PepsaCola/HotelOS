import type { PurchaseApproval } from "@/types/approvals";
import { formatMoney } from "@/lib/money";
import { calcPoTotals, deptAllocation } from "../lib/po";
import { SECTION_HEAD } from "./DetailTab";

interface LinesTabProps {
  po: PurchaseApproval;
}

const TH = "bg-surface-soft px-2.5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.06em] text-muted-strong";

export default function LinesTab({ po }: LinesTabProps) {
  const totals = calcPoTotals(po);
  const deptRows = deptAllocation(po, totals.total);

  return (
    <div>
      <div className={`${SECTION_HEAD} flex items-center justify-between`}>
        <span>Line items</span>
        <span className="rounded-full bg-surface-chip px-2 py-0.5 text-[10px] text-muted-strong">{po.lines.length} items</span>
      </div>

      <div className="overflow-hidden rounded-xl border border-hair-2 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr>
                <th className={`${TH} w-16 text-right`}>Qty / Unit</th>
                <th className={TH}>Description</th>
                <th className={`${TH} text-right`}>Unit price</th>
                <th className={`${TH} pr-4 text-right`}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {po.lines.map((line, i) => (
                <tr key={i} className="border-t border-hair">
                  <td className="px-2.5 py-2.5 text-right align-top">
                    <span className="block font-bold text-ink-900">{line.qty.toLocaleString("en-US")}</span>
                    <span className="block text-[11px] text-muted-strong">{line.pkg || "ea"}</span>
                  </td>
                  <td className="max-w-[220px] px-2.5 py-2.5 align-top font-medium leading-relaxed text-ink-900">{line.desc}</td>
                  <td className="whitespace-nowrap px-2.5 py-2.5 text-right align-top text-muted-strong">{formatMoney(line.unit)}</td>
                  <td className="whitespace-nowrap px-2.5 py-2.5 pr-4 text-right align-top font-semibold text-ink-900">
                    {formatMoney(line.qty * line.unit)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="h-px bg-hair-2" />

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr>
                <th className={`${TH} pl-4`}>Department</th>
                <th className={`${TH} text-right`}>Account</th>
                <th className={`${TH} pr-4 text-right`}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {deptRows.map((row, i) => (
                <tr key={i} className={`border-t border-hair ${row.active ? "bg-accent-soft/50" : ""}`}>
                  <td className={`px-2.5 py-2.5 pl-4 ${row.active ? "font-bold text-ink-900" : "text-muted-strong"}`}>{row.dept}</td>
                  <td className="px-2.5 py-2.5 text-right font-mono text-xs text-muted-strong">{row.account}</td>
                  <td className={`px-2.5 py-2.5 pr-4 text-right ${row.active ? "font-bold text-ink-900" : "text-muted-strong"}`}>
                    {row.amount != null ? formatMoney(row.amount) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="h-px bg-hair-2" />

        <div className="flex flex-col gap-1.5 bg-surface-soft p-4">
          {([["Subtotal", totals.subtotal], ["Shipping", totals.shipping], ["Tax", totals.tax]] as [string, number][]).map(
            ([label, value]) => (
              <div className="flex items-center justify-between text-sm" key={label}>
                <span className="text-muted-strong">{label}</span>
                <span className={`tabular-nums ${value === 0 ? "text-muted" : "font-medium text-ink-900"}`}>{formatMoney(value)}</span>
              </div>
            ),
          )}
          <div className="mt-2 flex items-center justify-between border-t border-hair-2 pt-3">
            <span className="text-sm font-semibold text-ink-700">Total</span>
            <span className="text-xl font-bold tabular-nums tracking-tight text-ink-900">{formatMoney(totals.total)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
