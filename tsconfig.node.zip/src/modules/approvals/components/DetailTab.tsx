import type { PurchaseApproval } from "@/types/approvals";
import { formatMoney } from "@/lib/money";
import { calcPoTotals, glAccount } from "../lib/po";
import ApprovalStepper from "./ApprovalStepper";
import { AlertIcon } from "./icons";

interface DetailTabProps {
  po: PurchaseApproval;
  reviewerName: string;
}

const SECTION_HEAD = "mb-3 border-b border-hair-2 pb-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-muted-strong";

export default function DetailTab({ po, reviewerName }: DetailTabProps) {
  const totals = calcPoTotals(po);
  const rows: [string, string][] = [
    ["PO Number", po.id],
    ["Vendor", po.vendor],
    ["Category", po.cat],
    ["Type", po.type],
    ["Department", po.dept],
    ["GL Account", glAccount(po)],
    ["Requested by", po.requester],
    ["Submitted", po.submitted],
    ["PO Date", po.poDate],
  ];

  return (
    <div className="flex flex-col gap-6">
      {po.overBudget ? (
        <div className="flex items-start gap-3 rounded-lg border border-crit-bg bg-crit-soft p-3">
          <AlertIcon className="mt-0.5 h-5 w-5 shrink-0 text-crit" />
          <div className="text-sm leading-relaxed text-crit">
            <strong className="font-bold">Over budget by {formatMoney(po.overAmt)}</strong> — this PO exceeds the
            approved department budget. A justification comment is required before approving.
          </div>
        </div>
      ) : null}

      <div>
        <div className={SECTION_HEAD}>PO Details</div>
        <div className="flex flex-col">
          {rows.map(([k, v]) => (
            <div className="flex items-center justify-between gap-4 border-b border-hair py-2 text-sm last:border-0" key={k}>
              <span className="text-xs text-muted-strong">{k}</span>
              <span className="font-medium text-ink-900">{v}</span>
            </div>
          ))}
          <div className="flex items-center justify-between gap-4 py-2 text-sm">
            <span className="text-xs text-muted-strong">Total</span>
            <span className="text-base font-bold tabular-nums text-ink-900">{formatMoney(totals.total)}</span>
          </div>
        </div>
      </div>

      {po.budget ? (
        <div>
          <div className={SECTION_HEAD}>Budget Snapshot</div>
          <div className="grid grid-cols-2 gap-2">
            <BudgetCard label="Dept Budget" value={formatMoney(po.budget.total)} />
            <BudgetCard label="Committed" value={formatMoney(po.budget.committed)} />
            <BudgetCard label="This PO" value={formatMoney(po.budget.thisPO)} />
            <BudgetCard
              label="Remaining"
              value={formatMoney(po.budget.remaining)}
              valueClass={po.budget.remaining < 0 ? "text-crit" : po.budget.remaining < 1000 ? "text-ink-900" : "text-good"}
            />
          </div>
        </div>
      ) : null}

      <div>
        <div className={SECTION_HEAD}>Approval Chain</div>
        <ApprovalStepper po={po} reviewerName={reviewerName} />
      </div>
    </div>
  );
}

function BudgetCard({ label, value, valueClass = "text-ink-900" }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="rounded-lg border border-hair-2 bg-surface-soft p-3">
      <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.06em] text-muted">{label}</div>
      <div className={`text-lg font-bold tabular-nums ${valueClass}`}>{value}</div>
    </div>
  );
}

export { SECTION_HEAD };
