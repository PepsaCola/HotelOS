import { DownloadIcon } from "@/components/ui/icons";

interface ApprovalsHeaderProps {
  subtitle: string;
}

export function ApprovalsHeader({ subtitle }: ApprovalsHeaderProps) {
  return (
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <h1 className="text-[28px] font-bold tracking-tight text-ink-900">Approvals</h1>
        <p className="mt-1 text-[13.5px] text-muted-strong">{subtitle}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <button className="inline-flex h-9 items-center gap-2 rounded-[9px] border border-hair-2 bg-white px-3.5 text-[13.5px] font-medium text-ink-900 hover:bg-surface-soft">
          <DownloadIcon className="h-[15px] w-[15px]" />
          Export Log
        </button>
      </div>
    </div>
  );
}
