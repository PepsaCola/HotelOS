import type { ApprovalDepartment } from "@/types/approvals";
import { FilterIcon } from "@/components/ui/icons";

export type DeptFilter = "all" | string;
export type TypeFilter = "all" | "Operational" | "Fixed / Recurring" | "CapEx" | "Prepaid";
export type SortKey = "oldest" | "newest" | "highest";

const TYPE_OPTIONS: TypeFilter[] = ["Operational", "Fixed / Recurring", "CapEx", "Prepaid"];
const SORT_LABELS: Record<SortKey, string> = {
  oldest: "Oldest first",
  newest: "Newest first",
  highest: "Highest amount",
};

interface ApprovalToolbarProps {
  departments: Record<string, ApprovalDepartment>;
  deptFilter: DeptFilter;
  setDeptFilter: (value: DeptFilter) => void;
  typeFilter: TypeFilter;
  setTypeFilter: (value: TypeFilter) => void;
  sort: SortKey;
  setSort: (value: SortKey) => void;
}

export function ApprovalToolbar({
  departments,
  deptFilter,
  setDeptFilter,
  typeFilter,
  setTypeFilter,
  sort,
  setSort,
}: ApprovalToolbarProps) {
  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-hair-2 bg-surface-soft p-3">
      <Select value={deptFilter} onChange={setDeptFilter}>
        <option value="all">All departments</option>
        {Object.keys(departments).map((dept) => (
          <option key={dept} value={dept}>
            {dept}
          </option>
        ))}
      </Select>

      <Select value={typeFilter} onChange={(v) => setTypeFilter(v as TypeFilter)}>
        <option value="all">All types</option>
        {TYPE_OPTIONS.map((type) => (
          <option key={type} value={type}>
            {type}
          </option>
        ))}
      </Select>

      <Select value={sort} onChange={(v) => setSort(v as SortKey)}>
        {(Object.keys(SORT_LABELS) as SortKey[]).map((key) => (
          <option key={key} value={key}>
            {SORT_LABELS[key]}
          </option>
        ))}
      </Select>

      <div className="flex-1" />

      <button className="inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium text-muted-strong hover:bg-surface-muted hover:text-ink-900">
        <FilterIcon className="h-3.5 w-3.5" />
        Filter
      </button>
    </div>
  );
}

function Select({ value, onChange, children }: { value: string; onChange: (value: string) => void; children: React.ReactNode }) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 cursor-pointer appearance-none rounded-lg border border-hair-2 bg-white pl-3 pr-8 text-sm text-ink-700"
      >
        {children}
      </select>
      <svg
        viewBox="0 0 10 6"
        aria-hidden="true"
        className="pointer-events-none absolute right-2.5 top-1/2 h-1.5 w-2.5 -translate-y-1/2 fill-muted-strong"
      >
        <path d="M0 0h10L5 6z" />
      </svg>
    </div>
  );
}
