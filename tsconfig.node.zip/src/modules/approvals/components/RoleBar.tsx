import type { ApprovalsMeta } from "@/types/approvals";
import { UserIcon } from "./icons";

interface RoleBarProps {
  meta: ApprovalsMeta;
}

export function RoleBar({ meta }: RoleBarProps) {
  const { reviewer, chain } = meta;
  const step = chain.activeIndex + 1;

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#d9dbff] bg-accent-soft px-4 py-2.5">
      <div className="flex items-center gap-2 text-sm font-medium text-accent-ink">
        <UserIcon className="h-4 w-4 text-accent" />
        Reviewing as <strong>{reviewer.role}</strong>
        <span className="opacity-70">
          — Step {step} of {chain.steps.length} in the approval chain
        </span>
      </div>
      <div className="hidden text-xs text-muted-strong sm:block">
        {chain.steps.map((label, i) => (
          <span key={label}>
            {i > 0 ? " → " : ""}
            {i === chain.activeIndex ? <strong className="text-ink-900">{label}</strong> : label}
          </span>
        ))}
      </div>
    </div>
  );
}
