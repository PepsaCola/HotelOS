import { useEffect, useState } from "react";
import type { ActionType, PurchaseApproval } from "@/types/approvals";
import { formatMoney } from "@/lib/money";
import { nextPendingStep } from "../lib/workflow";
import DetailTab from "./DetailTab";
import LinesTab from "./LinesTab";
import AuditTab from "./AuditTab";
import ActionSheet from "./ActionSheet";
import { AlertIcon, CapExIcon, ChangesIcon, CheckIcon, CloseIcon } from "./icons";

interface ApprovalDrawerProps {
  po: PurchaseApproval;
  acted: boolean;
  reviewerName: string;
  onClose: () => void;
  onAct: (poId: string, type: ActionType, comment: string) => void;
}

type TabKey = "detail" | "lines" | "audit";

const TABS: [TabKey, string][] = [
  ["detail", "PO Detail"],
  ["lines", "Line Items"],
  ["audit", "Audit Trail"],
];

export default function ApprovalDrawer({ po, acted, reviewerName, onClose, onAct }: ApprovalDrawerProps) {
  const [tab, setTab] = useState<TabKey>("detail");
  const [activeSheet, setActiveSheet] = useState<ActionType | null>(null);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const next = nextPendingStep(po);

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="Approval detail">
      <div className="absolute inset-0 animate-fade-in bg-[#0c1320]/35" onClick={onClose} />

      <div className="relative flex w-full max-w-full animate-slide-in-right flex-col bg-white shadow-[-12px_0_40px_rgba(0,0,0,0.18)] sm:w-[580px]">
        {/* Sticky header */}
        <div className="shrink-0 border-b border-hair-2 bg-white">
          <div className="relative p-5">
            <button
              type="button"
              aria-label="Close panel"
              onClick={onClose}
              className="absolute right-4 top-4 grid h-7 w-7 place-items-center rounded-md text-muted-strong hover:bg-surface-muted hover:text-ink-900"
            >
              <CloseIcon className="h-4 w-4" />
            </button>

            <div className="mb-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-[0.06em] text-muted">
              <span>{po.id}</span>
              <span className="text-hair-2">·</span>
              <span>{po.type}</span>
              <span className="text-hair-2">·</span>
              <span>{po.dept}</span>
            </div>

            <h2 className="mb-1 text-xl font-bold leading-tight text-ink-900">{po.vendor}</h2>

            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span className="text-xl font-bold tabular-nums text-ink-900">{formatMoney(po.amount)}</span>
              <span className="text-xs text-muted-strong">
                Requested by {po.requester} · {po.submitted}
              </span>
            </div>

            {po.overBudget || po.capex ? (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {po.overBudget ? (
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-crit-bg px-2 py-1 text-[11.5px] font-semibold text-crit">
                    <AlertIcon className="h-3.5 w-3.5" /> Over budget by {formatMoney(po.overAmt)}
                  </span>
                ) : null}
                {po.capex ? (
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-capex-bg px-2 py-1 text-[11.5px] font-semibold text-capex">
                    <CapExIcon className="h-3.5 w-3.5" /> CapEx — Corporate Approval Required
                  </span>
                ) : null}
              </div>
            ) : null}
          </div>

          <div className="flex px-5">
            {TABS.map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={`border-b-2 px-3.5 py-2.5 text-sm font-medium transition-colors ${
                  tab === key ? "border-accent text-ink-900" : "border-transparent text-muted-strong hover:text-ink-700"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto p-5">
          {tab === "detail" ? <DetailTab po={po} reviewerName={reviewerName} /> : null}
          {tab === "lines" ? <LinesTab po={po} /> : null}
          {tab === "audit" ? <AuditTab po={po} /> : null}
        </div>

        {/* Footer */}
        {acted ? (
          <div className="flex shrink-0 items-center justify-between gap-3 border-t border-hair-2 bg-white p-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-good">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-good text-white">
                <CheckIcon className="h-3.5 w-3.5" />
              </span>
              Action recorded
            </div>
            <div className="text-xs text-muted-strong">{next ? `Next: ${next.role} — ${next.name}` : "Approval complete"}</div>
          </div>
        ) : tab !== "audit" ? (
          <div className="shrink-0">
            {activeSheet ? (
              <ActionSheet
                type={activeSheet}
                po={po}
                onConfirm={(type, comment) => {
                  onAct(po.id, type, comment);
                  setActiveSheet(null);
                }}
                onCancel={() => setActiveSheet(null)}
              />
            ) : (
              <div className="flex gap-2 border-t border-hair-2 bg-white p-4">
                <button
                  type="button"
                  onClick={() => setActiveSheet("approve")}
                  className="flex h-10 flex-1 items-center justify-center gap-2 rounded-lg bg-good text-sm font-semibold text-white transition-colors hover:bg-[#0f5a37]"
                >
                  <CheckIcon className="h-[15px] w-[15px]" /> Approve
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSheet("changes")}
                  className="flex h-10 flex-1 items-center justify-center gap-2 rounded-lg border border-hair-2 bg-white text-sm font-semibold text-ink-700 transition-colors hover:bg-surface-soft"
                >
                  <ChangesIcon className="h-[15px] w-[15px]" /> Request Changes
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSheet("reject")}
                  className="flex h-10 flex-1 items-center justify-center gap-2 rounded-lg border border-crit-bg bg-white text-sm font-semibold text-crit transition-colors hover:bg-crit-soft"
                >
                  <CloseIcon className="h-[15px] w-[15px]" /> Reject
                </button>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}
