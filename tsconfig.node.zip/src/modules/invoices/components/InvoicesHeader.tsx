import { CalendarIcon, PlusIcon } from "@/components/ui/icons";
import { RefreshIcon } from "./icons";

interface InvoicesHeaderProps {
    month: string;
    lastSync: string;
    onAddInvoice: () => void;
}

export function InvoicesHeader({ month, lastSync, onAddInvoice }: InvoicesHeaderProps) {
    return (
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
                <h1 className="text-[28px] font-bold tracking-tight text-ink-900">Invoices</h1>
                <p className="mt-1 text-[13.5px] text-muted-strong">
                    {month} · last sync {lastSync}
                </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
                <button
                    type="button"
                    className="inline-flex h-9 items-center gap-2 rounded-[9px] border border-hair-2 bg-white px-3.5 text-[13.5px] font-medium text-ink-900 hover:bg-surface-soft"
                >
                    <RefreshIcon />
                    Refresh
                </button>
                <button
                    type="button"
                    className="inline-flex h-9 items-center gap-2 rounded-[9px] border border-hair-2 bg-white px-3.5 text-[13.5px] font-medium text-ink-900 hover:bg-surface-soft"
                >
                    <CalendarIcon className="h-[14px] w-[14px]" />
                    {month}
                </button>
                <button
                    type="button"
                    onClick={onAddInvoice}
                    className="inline-flex h-9 items-center gap-2 rounded-[9px] border border-ink-900 bg-ink-900 px-3.5 text-[13.5px] font-medium text-white hover:bg-black"
                >
                    <PlusIcon className="h-4 w-4" />
                    Add Invoice
                </button>
            </div>
        </div>
    );
}