import type { InvoiceDept, AmountRange, SortKey } from "@/types/invoices";
import { CloseIcon } from "@/components/ui/icons";
import { SORT_OPTIONS, AMOUNT_OPTIONS, DEPT_OPTIONS } from "../lib/filter";

interface InvoicesFilterBarProps {
    sort: SortKey;
    setSort: (v: SortKey) => void;
    vendor: string;
    setVendor: (v: string) => void;
    dept: InvoiceDept;
    setDept: (v: InvoiceDept) => void;
    amountRange: AmountRange;
    setAmountRange: (v: AmountRange) => void;
    vendors: string[];
    onClear: () => void;
}

export function InvoicesFilterBar({
                                      sort, setSort, vendor, setVendor, dept, setDept,
                                      amountRange, setAmountRange, vendors, onClear,
                                  }: InvoicesFilterBarProps) {
    const isFiltered = vendor !== "all" || dept !== "all" || amountRange !== "any" || sort !== "updated";

    return (
        <div className="flex flex-wrap items-center gap-2 border-b border-hair-2 bg-white px-3.5 py-2.5">
            <FilterChip label="Sort" value={SORT_OPTIONS.find((o) => o.key === sort)?.label ?? sort}>
                <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="absolute inset-0 cursor-pointer opacity-0">
                    {SORT_OPTIONS.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
                </select>
            </FilterChip>

            <FilterChip label="Vendor" value={vendor === "all" ? "All" : vendor} active={vendor !== "all"}>
                <select value={vendor} onChange={(e) => setVendor(e.target.value)} className="absolute inset-0 cursor-pointer opacity-0">
                    <option value="all">All</option>
                    {vendors.map((v) => <option key={v} value={v}>{v}</option>)}
                </select>
            </FilterChip>

            <FilterChip label="Department" value={dept === "all" ? "All" : dept} active={dept !== "all"}>
                <select value={dept} onChange={(e) => setDept(e.target.value as InvoiceDept)} className="absolute inset-0 cursor-pointer opacity-0">
                    {DEPT_OPTIONS.map((d) => <option key={d} value={d}>{d === "all" ? "All" : d}</option>)}
                </select>
            </FilterChip>

            <FilterChip label="Amount" value={AMOUNT_OPTIONS.find((o) => o.key === amountRange)?.label ?? "Any"} active={amountRange !== "any"}>
                <select value={amountRange} onChange={(e) => setAmountRange(e.target.value as AmountRange)} className="absolute inset-0 cursor-pointer opacity-0">
                    {AMOUNT_OPTIONS.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
                </select>
            </FilterChip>

            <div className="flex-1" />

            {isFiltered && (
                <button
                    type="button"
                    onClick={onClear}
                    className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[13px] font-medium text-muted-strong hover:bg-surface-chip hover:text-ink-900"
                >
                    <CloseIcon className="h-3.5 w-3.5" />
                    Clear
                </button>
            )}
        </div>
    );
}

function FilterChip({
                        label, value, active = false, children,
                    }: { label: string; value: string; active?: boolean; children: React.ReactNode }) {
    return (
        <div className="relative">
            <button
                type="button"
                className={`inline-flex h-8 items-center gap-1 rounded-lg border px-3 text-[13px] font-medium transition-colors ${
                    active
                        ? "border-accent bg-accent-soft text-accent-ink"
                        : "border-hair-2 bg-white text-ink-700 hover:bg-surface-soft"
                }`}
            >
                <span className="text-muted-strong">{label}:</span>
                <b className="font-semibold">{value}</b>
                <svg viewBox="0 0 24 24" className="ml-0.5 h-3 w-3 fill-muted-strong" aria-hidden="true">
                    <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                </svg>
            </button>
            {children}
        </div>
    );
}