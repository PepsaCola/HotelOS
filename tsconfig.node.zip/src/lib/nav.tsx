import type { ComponentType, SVGProps } from "react";
import {
  ApprovalIcon,
  DashboardIcon,
  DepartmentsIcon,
  ExceptionsIcon,
  ExportsIcon,
  InvoiceMappingIcon,
  InvoicesIcon,
  POLogIcon,
  ProfitswordIcon,
  ReceivingIcon,
  SettingsIcon,
  VendorsIcon,
} from "@/components/ui/icons";

export interface NavItem {
  path: string;
  label: string;
  /** Page title shown in the topbar breadcrumb. */
  title: string;
  /** Short subtitle describing the module. */
  subtitle: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
}

export const primaryNav: NavItem[] = [
  {
    path: "/dashboard",
    label: "Dashboard",
    title: "Dashboard",
    subtitle: "Daily visibility across approvals, budgets, and receiving.",
    icon: DashboardIcon,
  },
  {
    path: "/po-log",
    label: "PO Log",
    title: "Purchase Order Log",
    subtitle: "Track the queue, monitor risk, and review purchase order activity.",
    icon: POLogIcon,
  },
  {
    path: "/approval",
    label: "Approval",
    title: "Approvals",
    subtitle: "Review pending purchase orders and act on the approval chain.",
    icon: ApprovalIcon,
  },
  {
    path: "/receiving",
    label: "Receiving",
    title: "Receiving",
    subtitle: "Monitor PO fulfillment, remaining lines, and delivery status.",
    icon: ReceivingIcon,
  },
  {
    path: "/invoices",
    label: "Invoices",
    title: "Invoices",
    subtitle: "Receive, extract, match, approve, and stage invoices for export.",
    icon: InvoicesIcon,
  },
  {
    path: "/invoice-mapping",
    label: "Invoice Mapping",
    title: "Invoice Mapping",
    subtitle: "Match invoices against purchase orders and resolve discrepancies.",
    icon: InvoiceMappingIcon,
  },
  {
    path: "/exceptions",
    label: "Exceptions",
    title: "Exceptions",
    subtitle: "Investigate invoice and purchasing issues and resolve them.",
    icon: ExceptionsIcon,
  },
  {
    path: "/exports",
    label: "Exports / M3",
    title: "Exports / M3",
    subtitle: "Control the export pipeline from HotelOS to the M3 ERP.",
    icon: ExportsIcon,
  },
  {
    path: "/profitsword",
    label: "Profitsword",
    title: "Profitsword Imports",
    subtitle: "Import, validate, and audit budget & forecast files.",
    icon: ProfitswordIcon,
  },
  {
    path: "/vendors",
    label: "Vendors / Contracts",
    title: "Vendors & Contracts",
    subtitle: "Manage vendor details, contracts, and supplier information.",
    icon: VendorsIcon,
  },
  {
    path: "/departments",
    label: "Departments",
    title: "Departments",
    subtitle: "Review department budgets and account-level performance.",
    icon: DepartmentsIcon,
  },
];

export const secondaryNav: NavItem[] = [
  {
    path: "/settings",
    label: "Account Settings",
    title: "Account Settings",
    subtitle: "Manage profile, permissions, accounting structure, and integrations.",
    icon: SettingsIcon,
  },
];

export const allNav: NavItem[] = [...primaryNav, ...secondaryNav];

export function findNavByPath(pathname: string): NavItem | undefined {
  return allNav.find((item) => pathname.startsWith(item.path));
}
