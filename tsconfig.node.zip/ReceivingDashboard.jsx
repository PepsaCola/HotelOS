import { useState } from "react";

// ── Design tokens (mirrors the HTML CSS vars) ──────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');

  :root {
    --bg: #f6f6f4;
    --panel: #ffffff;
    --ink: #14151a;
    --ink-2: #3b3f47;
    --muted: #6b7079;
    --muted-2: #9aa0a8;
    --hair: #ececec;
    --hair-2: #e2e3e6;
    --indigo: #5b5bf2;
    --indigo-ink: #2a2ad6;
    --indigo-soft: #eef0ff;
    --amt-ink: #0c1320;
    --good: #157347;
    --good-bg: #e8f5ec;
    --warn: #a55a00;
    --warn-bg: #fdf1de;
    --crit: #b13434;
    --crit-bg: #fbe8e6;
    --neutral-bg: #eef0f3;
    --neutral-ink: #4a505a;
    --dept-rooms: #4a78f0;
    --dept-fb: #e88a3c;
    --dept-eng: #38a169;
    --dept-admin: #7a6df0;
    --dept-sales: #c7458a;
    --dept-sm: #119da4;
  }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 0; background: var(--bg); color: var(--ink);
    font-family: 'Inter', system-ui, sans-serif; font-feature-settings: "cv11","ss01";
    -webkit-font-smoothing: antialiased; }

  /* Scrollbar */
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--hair-2); border-radius: 999px; }

  /* Layout */
  .app { display: grid; grid-template-columns: 248px 1fr; height: 100vh; overflow: hidden; }

  /* Sidebar */
  .side { background: #fbfbfa; border-right: 1px solid var(--hair); padding: 16px 14px;
    display: flex; flex-direction: column; gap: 8px; height: 100vh; overflow-y: auto; }
  .brand { display: flex; align-items: center; gap: 10px; padding: 6px 6px 14px;
    justify-content: space-between; }
  .logo { width: 30px; height: 30px; border-radius: 8px;
    background: linear-gradient(160deg, #3637c2, #7677ff);
    display: grid; place-items: center; color: #fff; font-weight: 700; font-size: 15px;
    box-shadow: 0 1px 2px rgba(0,0,0,.15); flex-shrink: 0; }
  .brand-name { font-weight: 700; letter-spacing: -.02em; font-size: 15px; }
  .brand-name b { color: var(--indigo); }
  .collapse-btn { background: transparent; border: 0; color: var(--muted); cursor: pointer;
    padding: 6px; border-radius: 6px; display: grid; place-items: center; }
  .collapse-btn:hover { background: var(--hair); color: var(--ink); }

  .nav-cta { margin: 6px 0 8px; display: flex; align-items: center; gap: 8px;
    padding: 10px 12px; border-radius: 10px;
    background: linear-gradient(180deg, #6c6cff, #4747e8);
    color: #fff; font-weight: 600; border: 0; cursor: pointer; font-size: 13.5px;
    font-family: inherit; box-shadow: 0 1px 0 rgba(255,255,255,.25) inset, 0 1px 2px rgba(40,40,180,.35);
    width: 100%; }
  .nav-cta:hover { filter: brightness(1.05); }

  .nav { display: flex; flex-direction: column; gap: 2px; margin-top: 4px; }
  .nav-item { display: flex; align-items: center; gap: 10px; padding: 8px 10px;
    border-radius: 8px; color: var(--ink-2); text-decoration: none;
    font-size: 13.5px; font-weight: 500; cursor: pointer; background: none; border: 0;
    font-family: inherit; width: 100%; text-align: left; }
  .nav-item:hover { background: #f1f1ef; color: var(--ink); }
  .nav-item.active { background: var(--indigo-soft); color: var(--indigo-ink); }

  .side-foot { margin-top: auto; display: flex; flex-direction: column; gap: 2px;
    padding-top: 8px; border-top: 1px solid var(--hair); }
  .side-foot .nav-item { font-size: 13.5px; }

  /* Main */
  main { display: flex; flex-direction: column; min-width: 0; overflow: hidden; height: 100vh; }

  .topbar { display: flex; align-items: center; gap: 16px; padding: 12px 28px;
    border-bottom: 1px solid var(--hair); background: rgba(246,246,244,.85);
    backdrop-filter: blur(6px); position: sticky; top: 0; z-index: 30; flex-shrink: 0; }
  .crumb { color: var(--muted); font-size: 13.5px; }
  .crumb b { color: var(--ink-2); font-weight: 600; }
  .search-wrap { flex: 1; max-width: 520px; margin: 0 auto; position: relative; }
  .search-wrap input { width: 100%; height: 38px; border: 1px solid var(--hair-2);
    border-radius: 10px; background: #fff; padding: 0 14px 0 38px;
    font-size: 13.5px; color: var(--ink); font-family: inherit;
    box-shadow: 0 1px 0 rgba(0,0,0,.02); outline: none; }
  .search-wrap input:focus { border-color: #bcbef7; box-shadow: 0 0 0 3px #e8e9ff; }
  .search-wrap svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
    width: 16px; height: 16px; color: var(--muted); pointer-events: none; }
  .top-actions { display: flex; gap: 6px; align-items: center; }
  .icon-btn { width: 36px; height: 36px; display: grid; place-items: center;
    border-radius: 8px; background: transparent; border: 1px solid transparent;
    color: var(--muted-2); cursor: pointer; }
  .icon-btn:hover { background: #fff; color: var(--ink); border-color: var(--hair-2); }
  .avatar { width: 32px; height: 32px; border-radius: 50%;
    background: linear-gradient(160deg, #0c1320, #374055);
    color: #fff; font-weight: 600; display: grid; place-items: center; font-size: 13px; }

  .page { padding: 24px 28px 96px; overflow-y: auto; flex: 1; }
  .page-head { display: flex; align-items: flex-end; justify-content: space-between;
    gap: 24px; margin-bottom: 18px; flex-wrap: wrap; }
  h1.title { font-size: 28px; font-weight: 700; margin: 0; letter-spacing: -.025em; }
  .title-sub { color: var(--muted); font-size: 13.5px; margin-top: 4px; }
  .head-actions { display: flex; align-items: center; gap: 8px; }

  /* Buttons */
  .btn { height: 36px; padding: 0 14px; border-radius: 9px; border: 1px solid var(--hair-2);
    background: #fff; color: var(--ink); font-weight: 500; font-size: 13.5px;
    font-family: inherit; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }
  .btn:hover { background: #fafafa; border-color: #d6d8dc; }
  .btn.primary { background: var(--ink); color: #fff; border-color: var(--ink); }
  .btn.primary:hover { background: #000; }
  .btn.ghost { background: transparent; border-color: transparent; color: var(--ink-2); }
  .btn.ghost:hover { background: #ececeb; }
  .btn.sm { height: 28px; padding: 0 10px; font-size: 12.5px; border-radius: 7px; }

  /* KPIs */
  .kpis { display: grid; grid-template-columns: repeat(4,1fr); gap: 14px; margin-bottom: 22px; }
  .kpi { background: #fff; border: 1px solid var(--hair-2); border-radius: 14px;
    padding: 18px 18px 16px; display: flex; flex-direction: column; gap: 6px;
    position: relative; overflow: hidden; }
  .kpi.hero { background: linear-gradient(180deg,#101321 0%,#1a1f33 100%);
    color: #fff; border-color: #0d101a; }
  .kpi.hero .kpi-label, .kpi.hero .kpi-foot { color: rgba(255,255,255,.6); }
  .kpi.hero .kpi-sub { color: rgba(255,255,255,.8); }
  .kpi-label { font-size: 11px; font-weight: 600; letter-spacing: .08em;
    text-transform: uppercase; color: var(--muted);
    display: flex; align-items: center; gap: 6px; }
  .kpi-dot { width: 6px; height: 6px; border-radius: 50%; display: inline-block; }
  .kpi-num { font-size: 34px; font-weight: 700; letter-spacing: -.025em; color: var(--amt-ink);
    line-height: 1.05; display: flex; align-items: baseline; gap: 6px; font-variant-numeric: tabular-nums; }
  .kpi-sub { font-size: 12.5px; color: var(--muted-2); }
  .kpi-foot { margin-top: auto; font-size: 12px; color: var(--muted);
    display: flex; align-items: center; justify-content: space-between; gap: 8px; }
  .kpi-bar { height: 6px; border-radius: 999px; background: #ecedf0; overflow: hidden; margin-top: 8px; }
  .kpi.hero .kpi-bar { background: rgba(255,255,255,.12); }
  .kpi-bar-fill { display: block; height: 100%; border-radius: 999px; }
  .kpi-trend { display: inline-flex; align-items: center; gap: 3px; font-weight: 600;
    padding: 2px 6px; border-radius: 6px; font-size: 11.5px; }
  .kpi-trend.up { color: #0a6a3a; background: #dff3e6; }
  .kpi-trend.down { color: #a8341a; background: #fae3dc; }
  .kpi-trend.flat { color: var(--neutral-ink); background: var(--neutral-bg); }
  .kpi-spark { position: absolute; right: 14px; top: 14px; opacity: .85; }

  /* Tabs */
  .tabs { display: flex; gap: 2px; padding: 4px; background: #ececeb;
    border-radius: 11px; width: max-content; margin-bottom: 14px; }
  .tab-btn { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 500;
    color: var(--muted); background: transparent; border: 0; cursor: pointer;
    font-family: inherit; display: inline-flex; align-items: center; gap: 4px; }
  .tab-btn.active { background: #fff; color: var(--ink);
    box-shadow: 0 1px 2px rgba(0,0,0,.06), 0 0 0 1px var(--hair-2); }
  .badge-count { font-size: 11px; padding: 2px 6px; border-radius: 999px;
    background: #dcdde0; color: var(--ink-2); font-variant-numeric: tabular-nums; margin-left: 2px; }
  .tab-btn.active .badge-count { background: var(--indigo-soft); color: var(--indigo-ink); }
  .badge-count.crit { background: var(--crit-bg); color: var(--crit); }

  /* Toolbar */
  .toolbar { background: #fff; border: 1px solid var(--hair-2);
    border-radius: 14px 14px 0 0; padding: 12px 14px;
    display: flex; align-items: center; gap: 10px; border-bottom: 0; flex-wrap: wrap; }
  .month-btn { display: inline-flex; align-items: center; gap: 8px; padding: 7px 10px;
    border: 1px solid var(--hair-2); border-radius: 8px; background: #fafafa;
    font-size: 13px; font-weight: 500; cursor: pointer; font-family: inherit; color: var(--ink-2); }
  .month-btn:hover { background: #f0f0ef; }
  .chips { display: flex; gap: 6px; flex-wrap: wrap; }
  .chip { display: inline-flex; align-items: center; gap: 8px; padding: 7px 11px;
    border-radius: 9px; background: #f5f5f4; border: 1px solid transparent;
    cursor: pointer; font-size: 12.5px; font-weight: 500; color: var(--ink-2); font-family: inherit; }
  .chip:hover { background: #ececeb; }
  .chip.on { background: #fff; border-color: #d7dbe3; color: var(--ink);
    box-shadow: 0 1px 2px rgba(0,0,0,.04); }
  .dept-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; }
  .chip-ct { color: var(--muted-2); font-weight: 500; }
  .chip.on .chip-ct { color: var(--muted); }
  .spacer { flex: 1; }
  .sel { height: 34px; padding: 0 28px 0 10px; border-radius: 8px;
    border: 1px solid var(--hair-2); background: #fff; font-size: 13px;
    color: var(--ink-2); cursor: pointer; font-family: inherit; appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='%236b7079' d='M0 0h10L5 6z'/></svg>");
    background-repeat: no-repeat; background-position: right 10px center; }

  /* Table */
  .table-wrap { background: #fff; border: 1px solid var(--hair-2);
    border-top: 1px solid var(--hair); border-radius: 0 0 14px 14px; overflow: hidden; }
  table.recv { width: 100%; border-collapse: collapse; font-size: 13.5px; }
  table.recv thead th { text-align: left; font-size: 11px; font-weight: 600;
    letter-spacing: .06em; text-transform: uppercase; color: var(--muted);
    padding: 12px 14px; background: #fafafa; border-bottom: 1px solid var(--hair-2); }
  table.recv thead th.r { text-align: right; }
  table.recv tbody td { padding: 0 14px; height: 52px; border-bottom: 1px solid var(--hair);
    vertical-align: middle; }
  table.recv tbody tr:last-child td { border-bottom: none; }
  tr.r-row:hover { background: #fafbff; cursor: pointer; }

  td.po-num { font-weight: 600; color: var(--ink); }
  .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; font-size: 12.5px; }
  .sub { display: block; font-size: 11.5px; color: var(--muted-2); margin-top: 1px; font-weight: 500; }
  td.vendor { color: var(--ink-2); font-weight: 500; }
  .dept-pill { display: inline-flex; align-items: center; gap: 6px; padding: 3px 9px 3px 8px;
    border-radius: 999px; background: #f4f4f3; font-size: 12px; font-weight: 500; color: var(--ink-2); }
  td.amt-td { text-align: right; font-weight: 600; color: var(--amt-ink);
    font-size: 14px; font-variant-numeric: tabular-nums; }
  td.date-td { color: var(--ink-2); white-space: nowrap; font-variant-numeric: tabular-nums; font-size: 13px; }
  td.date-td.warn { color: var(--warn); font-weight: 600; }
  td.date-td.crit { color: var(--crit); font-weight: 600; }

  .progress-wrap { display: flex; flex-direction: column; gap: 5px; }
  .progress-text { font-size: 12.5px; font-weight: 600; color: var(--ink-2);
    display: flex; justify-content: space-between; font-variant-numeric: tabular-nums; }
  .pct { color: var(--muted-2); font-weight: 500; }
  .progress-bar { height: 5px; background: #ecedf0; border-radius: 999px; overflow: hidden; min-width: 120px; }

  .badge { display: inline-flex; align-items: center; gap: 5px; padding: 3px 9px;
    border-radius: 999px; font-size: 11.5px; font-weight: 600; line-height: 1; white-space: nowrap; }
  .b-dot { width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0; display: inline-block; }
  .badge.good { background: var(--good-bg); color: var(--good); }
  .badge.good .b-dot { background: var(--good); }
  .badge.warn { background: var(--warn-bg); color: var(--warn); }
  .badge.warn .b-dot { background: var(--warn); }
  .badge.crit { background: var(--crit-bg); color: var(--crit); }
  .badge.crit .b-dot { background: var(--crit); }
  .badge.neutral { background: var(--neutral-bg); color: var(--neutral-ink); }
  .badge.indigo { background: var(--indigo-soft); color: var(--indigo-ink); }
  .badge.indigo .b-dot { background: var(--indigo); }

  td.actions-td { white-space: nowrap; }

  /* Pager */
  .pager { display: grid; grid-template-columns: 1fr auto 1fr; align-items: center;
    padding: 16px 24px; background: transparent; }
  .pager-left { color: #787787; font-size: 13px; }
  .pager-left b { color: #29253b; font-weight: 500; }
  .pager-center { display: flex; align-items: center; justify-content: center;
    gap: 8px; color: var(--muted); font-size: 13px; }
  .pager-right { display: flex; align-items: center; justify-content: flex-end;
    gap: 12px; color: #686770; font-size: 13px; }
  .pages { display: flex; align-items: center; gap: 2px; }
  .p-btn { width: 32px; height: 32px; display: grid; place-items: center;
    border-radius: 8px; color: #686770; cursor: pointer; font-size: 14px;
    font-variant-numeric: tabular-nums; background: transparent; border: 0;
    font-family: inherit; padding: 0; }
  .p-btn:hover { background: #f5f6f9; }
  .p-btn.active { background: transparent; color: #29253b;
    border: 1px solid #6366f1; font-weight: 500; }
  .p-btn.arrow { color: #686770; }
  .p-btn.disabled { opacity: .3; pointer-events: none; }
  .ellipsis { color: #686770; font-size: 14px; padding: 0 12px; }

  /* Detail view */
  .po-title-block { display: flex; gap: 16px; align-items: flex-start; }
  .back-btn { width: 38px; height: 38px; border-radius: 9px; border: 1px solid var(--hair-2);
    background: #fff; color: var(--ink-2); display: grid; place-items: center;
    cursor: pointer; flex-shrink: 0; }
  .back-btn:hover { background: #fafafa; }
  .po-meta-row { display: flex; align-items: center; gap: 10px; color: var(--muted);
    font-size: 12.5px; margin-bottom: 4px; flex-wrap: wrap; }
  .sep { color: var(--muted-2); }
  .po-tabs { display: flex; gap: 2px; padding: 4px; background: #ececeb;
    border-radius: 11px; width: max-content; margin-bottom: 18px; }
  .po-tab { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 500;
    color: var(--muted); background: transparent; border: 0; cursor: pointer;
    font-family: inherit; display: inline-flex; align-items: center; gap: 6px; }
  .po-tab.active { background: #fff; color: var(--ink);
    box-shadow: 0 1px 2px rgba(0,0,0,.06), 0 0 0 1px var(--hair-2); }
  .po-tab .badge-count { font-size: 11px; padding: 2px 6px; border-radius: 999px;
    background: #dcdde0; color: var(--ink-2); }
  .po-tab.active .badge-count { background: var(--indigo-soft); color: var(--indigo-ink); }

  .summary-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
    gap: 0; background: #fff; border: 1px solid var(--hair-2);
    border-radius: 14px; overflow: hidden; margin-bottom: 22px; }
  .s-cell { padding: 14px 18px; border-right: 1px solid var(--hair); }
  .s-cell:last-child { border-right: 0; }
  .s-cell .k { font-size: 11px; font-weight: 600; letter-spacing: .08em;
    text-transform: uppercase; color: var(--muted); margin-bottom: 5px; }
  .s-cell .v { font-size: 14px; font-weight: 600; color: var(--ink); }
  .s-cell .v.large { font-size: 20px; letter-spacing: -.01em; font-variant-numeric: tabular-nums; }
  .s-cell .v-sub { font-size: 12px; color: var(--muted); margin-top: 3px; font-weight: 500; }
  .s-cell .v.good { color: var(--good); }
  .s-cell .v.warn { color: var(--warn); }
  .progress-strip { padding: 14px 18px; background: #fafafa;
    border-top: 1px solid var(--hair); grid-column: 1 / -1; }
  .strip-row { display: flex; align-items: center; gap: 12px; }
  .strip-lbl { font-size: 11.5px; font-weight: 600; color: var(--muted);
    text-transform: uppercase; letter-spacing: .05em; min-width: 110px; }
  .strip-bar { flex: 1; height: 8px; background: #ecedf0; border-radius: 999px;
    overflow: hidden; position: relative; }
  .strip-text { font-size: 13px; font-weight: 600; color: var(--ink-2);
    font-variant-numeric: tabular-nums; min-width: 100px; text-align: right; }

  .sect-heading { font-size: 11px; font-weight: 600; letter-spacing: .08em;
    text-transform: uppercase; color: var(--muted); margin: 4px 0 12px;
    display: flex; align-items: center; gap: 10px; }
  .sect-heading::after { content: ""; flex: 1; height: 1px; background: var(--hair); }
  .panel-block { margin-bottom: 18px; }
  .detail-table-wrap { background: #fff; border: 1px solid var(--hair-2); border-radius: 14px; overflow: hidden; }
  .detail-table-title { padding: 14px; font-size: 11px; font-weight: 600;
    letter-spacing: .06em; text-transform: uppercase; color: var(--muted);
    border-bottom: 1px solid var(--hair-2); background: #fff; }
  .items-table, .event-lines { width: 100%; border-collapse: collapse; font-size: 13.5px; background: #fff; }
  .items-table thead th, .event-lines thead th { text-align: left; font-size: 11px;
    font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: var(--muted);
    padding: 12px 14px; background: #fafafa; border-bottom: 1px solid var(--hair-2); }
  .items-table thead th.r, .event-lines thead th.r { text-align: right; }
  .items-table thead th.c, .event-lines thead th.c { text-align: center; }
  .items-table tbody td, .event-lines tbody td { padding: 14px; border-bottom: 1px solid var(--hair); vertical-align: top; }
  .items-table tbody tr:last-child td, .event-lines tbody tr:last-child td { border-bottom: 0; }
  .items-table td.r, .event-lines td.r { text-align: right; font-variant-numeric: tabular-nums; font-weight: 500; }
  .items-table td.c, .event-lines td.c { text-align: center; }
  .line-name { display: block; font-weight: 500; color: var(--ink); line-height: 1.45; }
  .table-unit { font-weight: 500; color: var(--ink); }
  .table-desc { max-width: 420px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

  .metric-pill { display: inline-flex; align-items: center; justify-content: center;
    min-width: 44px; padding: 4px 10px; border-radius: 999px; font-size: 11.5px;
    font-weight: 600; font-variant-numeric: tabular-nums; }
  .metric-pill.received { background: var(--good-bg); color: var(--good); }
  .metric-pill.missing { background: var(--warn-bg); color: var(--warn); }
  .metric-pill.none { background: var(--neutral-bg); color: var(--neutral-ink); }

  .exc-pill { display: inline-flex; align-items: center; gap: 5px; padding: 3px 9px;
    border-radius: 999px; font-size: 11.5px; font-weight: 600; }
  .exc-pill .b-dot { width: 5px; height: 5px; border-radius: 50%; }
  .exc-pill.warn { background: var(--warn-bg); color: var(--warn); }
  .exc-pill.warn .b-dot { background: var(--warn); }
  .exc-pill.good { background: var(--good-bg); color: var(--good); }
  .exc-pill.good .b-dot { background: var(--good); }
  .exc-pill.crit { background: var(--crit-bg); color: var(--crit); }
  .exc-pill.crit .b-dot { background: var(--crit); }

  /* Timeline */
  .timeline { display: flex; flex-direction: column; gap: 14px; position: relative; padding-left: 26px; }
  .timeline::before { content: ""; position: absolute; left: 0; top: 14px;
    bottom: 14px; width: 1px; background: var(--hair-2); }
  .event { background: #fff; border: 1px solid var(--hair-2); border-radius: 14px;
    overflow: hidden; position: relative; }
  .event::before { content: ""; position: absolute; left: -22px; top: 30px;
    width: 10px; height: 10px; border-radius: 50%; background: var(--indigo);
    border: 2px solid var(--bg); }
  .event.last::before { background: var(--neutral-ink); }
  .event-head { display: grid; grid-template-columns: 44px 1fr auto; gap: 14px;
    align-items: center; padding: 14px 18px; border-bottom: 1px solid var(--hair); }
  .event-icon { width: 44px; height: 44px; border-radius: 12px; display: grid; place-items: center; flex-shrink: 0; }
  .event-icon.good { background: var(--good-bg); color: var(--good); }
  .event-icon.warn { background: var(--warn-bg); color: var(--warn); }
  .event-title { display: flex; flex-direction: column; gap: 3px; }
  .event-title h3 { margin: 0; font-size: 15px; font-weight: 700; letter-spacing: -.01em; }
  .event-sub { font-size: 12.5px; color: var(--muted); display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .event-amt { text-align: right; display: flex; flex-direction: column; align-items: flex-end; gap: 10px; }
  .event-head-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .event-body { padding: 16px; }
  .invoice-footer { display: grid; grid-template-columns: minmax(0,1.3fr) minmax(300px,.9fr);
    gap: 20px; padding: 16px; border-top: 1px solid var(--hair); align-items: start; }
  .invoice-note { font-size: 12.5px; color: var(--ink-2); display: flex; align-items: flex-start; gap: 8px; }
  .invoice-note .note-lbl { font-weight: 600; color: var(--muted); margin-right: 4px; }
  .invoice-summary { margin-left: auto; width: 100%; max-width: 340px; }
  .invoice-summary-row { display: flex; align-items: baseline; justify-content: space-between;
    gap: 16px; padding: 4px 0; color: var(--amt-ink); }
  .invoice-summary-row .lbl { font-size: 14px; color: var(--ink-2); }
  .invoice-summary-row .val { font-size: 14px; font-weight: 700; font-variant-numeric: tabular-nums; }
  .invoice-summary-total { margin-top: 10px; padding-top: 12px; border-top: 2px solid #2f2b45; }
  .invoice-summary-total .lbl { font-size: 18px; font-weight: 600; color: var(--amt-ink); }
  .invoice-summary-total .val { font-size: 18px; font-weight: 700; letter-spacing: -.02em; }
  .detail-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
`;

// ── SVG helpers ────────────────────────────────────────────────────────────
const Icon = {
  Plus: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>,
  ChevL: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M15 6l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  ChevR: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M9 6l6 6-6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  Search: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.6"/><path d="m20 20-3.5-3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  Bell: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2H4.5L6 16Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"/><path d="M10 21a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.6"/></svg>,
  Help: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.6"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.6 2.2c-.7.35-1.1.9-1.1 1.6V14M12 17.5h.01" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  Cal: () => <svg viewBox="0 0 24 24" fill="none" width={14} height={14}><rect x="3.5" y="5" width="17" height="15" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  Download: () => <svg viewBox="0 0 24 24" fill="none" width={15} height={15}><path d="M12 4v12m0 0l-4-4m4 4l4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M5 18v1a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
  CollapseL: () => <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M14 7l-5 5 5 5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/><path d="M20 4v16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  DocIcon: () => <svg viewBox="0 0 24 24" fill="none" width={15} height={15}><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/></svg>,
  InvoiceIcon: () => <svg viewBox="0 0 24 24" fill="none" width={22} height={22}><rect x="5" y="3.5" width="14" height="17" rx="2" stroke="currentColor" strokeWidth="1.6"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
  NoteLines: () => <svg viewBox="0 0 24 24" fill="none" width={14} height={14}><path d="M4 5h16M4 10h16M4 15h10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>,
};

// ── Data ───────────────────────────────────────────────────────────────────
const PO_ROWS = [
  { id:"PO-2026-0418", lines:"8 lines · Mar 22", vendor:"HD Supply Facilities", vendorSub:"Maintenance Supplies", dept:"R&M", deptColor:"var(--dept-eng)", amount:"$2,641", linesRcv:"0 of 8 lines", expected:"Apr 12, 2026", expectedSub:"8 days overdue", dateCls:"crit", progress:0, progressType:"zero", status:"overdue", statusBadge:"crit", statusLabel:"Overdue", opacity:1 },
  { id:"PO-2026-0421", lines:"3 lines · Mar 28", vendor:"Bell Transit Co.", vendorSub:"Guest Transportation", dept:"Rooms", deptColor:"var(--dept-rooms)", amount:"$1,180", linesRcv:"0 of 3 lines", expected:"Apr 15, 2026", expectedSub:"5 days overdue", dateCls:"crit", progress:0, progressType:"zero", status:"overdue", statusBadge:"crit", statusLabel:"Overdue", opacity:1 },
  { id:"PO-2026-0436", lines:"5 lines · Apr 1", vendor:"Four Winds Interactive LLC", vendorSub:"Poppulo / Digital Signage Renewal", dept:"IT", deptColor:"var(--dept-sm)", amount:"$5,445", linesRcv:"4 of 5 lines", expected:"May 1, 2026", expectedSub:"license true-up pending", dateCls:"warn", progress:76, progressType:"partial", status:"partial", statusBadge:"warn", statusLabel:"Partial", opacity:1 },
  { id:"PO-2026-0441", lines:"6 lines · Apr 10", vendor:"Cintas Corporation", vendorSub:"Cleaning Supplies", dept:"Rooms", deptColor:"var(--dept-rooms)", amount:"$1,850", linesRcv:"4 of 6 lines", expected:"Apr 22, 2026", expectedSub:"2 days remaining", dateCls:"", progress:67, progressType:"partial", status:"partial", statusBadge:"warn", statusLabel:"Partial", opacity:1 },
  { id:"PO-2026-0447", lines:"4 lines · Apr 14", vendor:"Aramark Uniform Services", vendorSub:"Laundry & Uniforms", dept:"Rooms", deptColor:"var(--dept-rooms)", amount:"$2,200", linesRcv:"0 of 4 lines", expected:"Apr 20, 2026", expectedSub:"due today", dateCls:"", progress:0, progressType:"zero", status:"today", statusBadge:"indigo", statusLabel:"Awaiting", opacity:1 },
  { id:"PO-2026-0449", lines:"3 lines · Apr 15", vendor:"ABC Pest Control of Orlando", vendorSub:"Pest Control", dept:"R&M", deptColor:"var(--dept-eng)", amount:"$627", linesRcv:"0 of 3 lines", expected:"Apr 21, 2026", expectedSub:"tomorrow", dateCls:"", progress:0, progressType:"zero", status:"awaiting", statusBadge:"indigo", statusLabel:"Awaiting", opacity:1 },
  { id:"PO-2026-0452", lines:"7 lines · Apr 16", vendor:"Coffee Company of Orlando", vendorSub:"Beverage Services", dept:"F&B", deptColor:"var(--dept-fb)", amount:"$2,863", linesRcv:"0 of 7 lines", expected:"Apr 23, 2026", expectedSub:"in 3 days", dateCls:"", progress:0, progressType:"zero", status:"awaiting", statusBadge:"indigo", statusLabel:"Awaiting", opacity:1 },
  { id:"PO-2026-0455", lines:"5 lines · Apr 17", vendor:"Ferran HVAC Services", vendorSub:"HVAC & Mechanical", dept:"R&M", deptColor:"var(--dept-eng)", amount:"$1,916", linesRcv:"0 of 5 lines", expected:"Apr 24, 2026", expectedSub:"in 4 days", dateCls:"", progress:0, progressType:"zero", status:"awaiting", statusBadge:"indigo", statusLabel:"Awaiting", opacity:1 },
  { id:"PO-2026-0442", lines:"5 lines · Apr 11", vendor:"Clean Tec Services LLC", vendorSub:"Cleaning & Remediation", dept:"R&M", deptColor:"var(--dept-eng)", amount:"$5,174", linesRcv:"5 of 5 lines", expected:"Apr 18, 2026", expectedSub:"received 2 days ago", dateCls:"", progress:100, progressType:"full", status:"received", statusBadge:"good", statusLabel:"Received", opacity:0.78 },
  { id:"PO-2026-0444", lines:"2 lines · Apr 12", vendor:"Cintas Corporation", vendorSub:"Cleaning Supplies", dept:"Rooms", deptColor:"var(--dept-rooms)", amount:"$840", linesRcv:"2 of 2 — over by 1", expected:"Apr 17, 2026", expectedSub:"received 3 days ago", dateCls:"", progress:100, progressType:"over", status:"received", statusBadge:"warn", statusLabel:"Over-received", opacity:0.78 },
];

const PROGRESS_BAR_GRADIENT = {
  full: "linear-gradient(90deg,#76e2a2,#34a86b)",
  partial: "linear-gradient(90deg,#f5c26b,#e8920a)",
  zero: "#d6d8dc",
  over: "linear-gradient(90deg,#f78080,#c93a3a)",
};

function ProgressBar({ pct, type }) {
  return (
    <div className="progress-bar" style={{ background: "#ecedf0" }}>
      <div style={{ height: "100%", width: `${pct}%`, background: PROGRESS_BAR_GRADIENT[type] || "#d6d8dc", borderRadius: 999 }} />
    </div>
  );
}

// ── Detail view (PO-2026-0436) ─────────────────────────────────────────────
function DetailView({ onBack }) {
  const [detailTab, setDetailTab] = useState("items");

  const itemsData = [
    { qty:10, unit:"Item", desc:"Poppulo Harmony - DS Device - Pro", rcv:8, miss:2, unit_price:"$291.74", amount:"$2,917.40", exc:"warn", excLabel:"Partial" },
    { qty:2,  unit:"Item", desc:"Poppulo Harmony - DS Device - Pro", rcv:2, miss:0, unit_price:"$453.73", amount:"$907.46", exc:"good", excLabel:"Complete" },
    { qty:1,  unit:"Item", desc:"Poppulo Harmony - Admin User", rcv:1, miss:0, unit_price:"$1,237.43", amount:"$1,237.43", exc:"good", excLabel:"Complete" },
    { qty:3,  unit:"Item", desc:"Poppulo Harmony - DS Contributor User", rcv:1, miss:2, unit_price:"$127.48", amount:"$382.44", exc:"warn", excLabel:"Partial" },
    { qty:1,  unit:"Item", desc:"Poppulo Harmony - Digital Signage - Pro", rcv:1, miss:0, unit_price:"$0.00", amount:"$0.00", exc:"good", excLabel:"Complete" },
  ];

  return (
    <>
      <div className="page-head">
        <div className="po-title-block">
          <button className="back-btn" onClick={onBack}><Icon.ChevL /></button>
          <div>
            <div className="po-meta-row">
              <span>Four Winds Interactive LLC · IT</span>
              <span className="sep">·</span>
              <span style={{background:"var(--warn-bg)",color:"var(--warn)",padding:"3px 9px",borderRadius:999,fontSize:"11.5px",fontWeight:600,display:"inline-flex",alignItems:"center",gap:5}}>
                <span style={{width:5,height:5,borderRadius:"50%",background:"var(--warn)",display:"inline-block"}}></span>Partially Received
              </span>
            </div>
            <h1 className="title mono" style={{fontSize:18,letterSpacing:"-.01em",marginTop:2}}>PO-2026-0436</h1>
            <div className="title-sub">Poppulo / Digital Signage Renewal</div>
          </div>
        </div>
        <div className="detail-actions">
          <button className="btn"><Icon.DocIcon /><span>View PO Form</span></button>
        </div>
      </div>

      <div className="po-tabs">
        {[{id:"items",label:"List of Items",count:5},{id:"history",label:"History",count:2}].map(t=>(
          <button key={t.id} className={`po-tab${detailTab===t.id?" active":""}`} onClick={()=>setDetailTab(t.id)}>
            {t.label} <span className="badge-count">{t.count}</span>
          </button>
        ))}
      </div>

      <div className="summary-grid">
        <div className="s-cell"><div className="k">Billed To</div><div className="v">DoubleTree by Hilton Orlando Airport</div><div className="v-sub">Ken Wear</div></div>
        <div className="s-cell"><div className="k">Vendor</div><div className="v">Four Winds Interactive LLC</div><div className="v-sub">Poppulo / Digital Signage Renewal</div></div>
        <div className="s-cell"><div className="k">Account Number</div><div className="v">4122367808</div><div className="v-sub"></div></div>
        <div className="s-cell"><div className="k">Date</div><div className="v">Apr 1, 2026</div><div className="v-sub">Due May 1, 2026 · Net 30</div></div>
        <div className="s-cell"><div className="k">Total</div><div className="v large">$5,444.73</div><div className="v-sub">Shipping $0.00 · Tax $0.00</div></div>
        <div className="progress-strip">
          <div className="strip-row">
            <span className="strip-lbl">Line Progress</span>
            <div className="strip-bar">
              <div style={{position:"absolute",top:0,bottom:0,left:0,width:"53%",background:"linear-gradient(90deg,#76e2a2,#34a86b)"}}/>
              <div style={{position:"absolute",top:0,bottom:0,left:"53%",width:"23%",background:"linear-gradient(90deg,#f5c26b,#e8920a)"}}/>
            </div>
            <span className="strip-text">4 / 5 lines · 76%</span>
          </div>
        </div>
      </div>

      {detailTab === "items" && (
        <div className="panel-block">
          <div className="detail-table-wrap">
            <div className="detail-table-title">List of Items</div>
            <table className="items-table">
              <thead><tr>
                <th className="r">Qty</th><th>Package/Unit #</th><th>Description</th>
                <th className="c">Received</th><th className="c">Missing</th>
                <th className="r">Unit Price</th><th className="r">Amount</th><th className="c">Status</th>
              </tr></thead>
              <tbody>
                {itemsData.map((r,i)=>(
                  <tr key={i}>
                    <td className="r">{r.qty}</td>
                    <td><span className="table-unit">{r.unit}</span></td>
                    <td className="table-desc"><span className="line-name">{r.desc}</span></td>
                    <td className="c"><span className={`metric-pill ${r.rcv>0?"received":"none"}`}>{r.rcv}</span></td>
                    <td className="c"><span className={`metric-pill ${r.miss>0?"missing":"none"}`}>{r.miss}</span></td>
                    <td className="r">{r.unit_price}</td>
                    <td className="r">{r.amount}</td>
                    <td className="c"><span className={`exc-pill ${r.exc}`}><span className="b-dot"></span>{r.excLabel}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {detailTab === "history" && (
        <div className="panel-block">
          <div className="sect-heading">Invoices Timeline · newest first</div>
          <div className="timeline">
            {/* Event 1 — partial */}
            <div className="event">
              <div className="event-head">
                <div className="event-icon warn"><Icon.InvoiceIcon /></div>
                <div className="event-title">
                  <h3>Invoice INV0685304</h3>
                  <div className="event-sub">
                    <span><b style={{color:"var(--ink-2)"}}>Apr 1, 2026 · 3:14 PM</b></span>
                    <span className="sep">·</span><span>Updated by <b style={{color:"var(--ink-2)"}}>Ken Wear</b></span>
                    <span className="sep">·</span><span>Partial PO fulfillment</span>
                  </div>
                </div>
                <div className="event-amt">
                  <div className="event-head-actions">
                    <button className="btn sm ghost">Add Note</button>
                    <button className="btn sm">View Invoice</button>
                  </div>
                </div>
              </div>
              <div className="event-body">
                <div className="detail-table-wrap">
                  <table className="event-lines">
                    <thead><tr>
                      <th className="r">Qty</th><th>Package/Unit #</th><th>Description</th>
                      <th className="r">Unit Price</th><th className="r">Amount</th>
                    </tr></thead>
                    <tbody>
                      {[
                        {qty:8,desc:"Poppulo Harmony - DS Device - Pro",up:"$291.74",amt:"$2,333.92"},
                        {qty:1,desc:"Poppulo Harmony - Admin User",up:"$1,237.43",amt:"$1,237.43"},
                        {qty:1,desc:"Poppulo Harmony - DS Contributor User",up:"$127.48",amt:"$127.48"},
                        {qty:1,desc:"Poppulo Harmony - Digital Signage - Pro",up:"$0.00",amt:"$0.00"},
                      ].map((r,i)=>(
                        <tr key={i}>
                          <td className="r">{r.qty}</td>
                          <td><span className="table-unit">Item</span></td>
                          <td className="table-desc"><span className="line-name">{r.desc}</span></td>
                          <td className="r">{r.up}</td>
                          <td className="r">{r.amt}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="invoice-footer">
                <div className="invoice-note">
                  <Icon.NoteLines />
                  <div><span className="note-lbl">Note:</span>Invoice INV0685304 covered the first 8 device licenses, 1 admin user, 1 contributor user, and the bundled signage platform. Two device licenses and two contributor users still remained open.</div>
                </div>
                <div className="invoice-summary">
                  {[["Subtotal:","$4,527.29"],["Shipping:","$0.00"],["Tax:","$0.00"]].map(([l,v])=>(
                    <div key={l} className="invoice-summary-row"><span className="lbl">{l}</span><span className="val">{v}</span></div>
                  ))}
                  <div className="invoice-summary-row invoice-summary-total">
                    <span className="lbl">Total</span><span className="val">$4,527.29</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Event 2 — complete */}
            <div className="event last">
              <div className="event-head">
                <div className="event-icon good"><Icon.InvoiceIcon /></div>
                <div className="event-title">
                  <h3>Invoice INV0685317</h3>
                  <div className="event-sub">
                    <span><b style={{color:"var(--ink-2)"}}>Apr 6, 2026 · 10:22 AM</b></span>
                    <span className="sep">·</span><span>Updated by <b style={{color:"var(--ink-2)"}}>HotelOS Matching Bot</b></span>
                    <span className="sep">·</span><span>Final PO completion</span>
                  </div>
                </div>
                <div className="event-amt">
                  <div className="event-head-actions">
                    <button className="btn sm ghost">Add Note</button>
                    <button className="btn sm">View Invoice</button>
                  </div>
                </div>
              </div>
              <div className="event-body">
                <div className="detail-table-wrap">
                  <table className="event-lines">
                    <thead><tr>
                      <th className="r">Qty</th><th>Package/Unit #</th><th>Description</th>
                      <th className="r">Unit Price</th><th className="r">Amount</th>
                    </tr></thead>
                    <tbody>
                      {[
                        {qty:2,desc:"Poppulo Harmony - DS Device - Pro",up:"$453.73",amt:"$907.46"},
                        {qty:2,desc:"Poppulo Harmony - DS Contributor User",up:"$127.48",amt:"$254.96"},
                      ].map((r,i)=>(
                        <tr key={i}>
                          <td className="r">{r.qty}</td>
                          <td><span className="table-unit">Item</span></td>
                          <td className="table-desc"><span className="line-name">{r.desc}</span></td>
                          <td className="r">{r.up}</td>
                          <td className="r">{r.amt}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="invoice-footer">
                <div className="invoice-note">
                  <Icon.NoteLines />
                  <div><span className="note-lbl">Note:</span>Invoice INV0685317 delivered the remaining 2 device licenses and the last 2 contributor seats, bringing the PO to full completion.</div>
                </div>
                <div className="invoice-summary">
                  {[["Subtotal:","$1,162.42"],["Shipping:","$0.00"],["Tax:","$0.00"]].map(([l,v])=>(
                    <div key={l} className="invoice-summary-row"><span className="lbl">{l}</span><span className="val">{v}</span></div>
                  ))}
                  <div className="invoice-summary-row invoice-summary-total">
                    <span className="lbl">Total</span><span className="val">$1,162.42</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ── List view ──────────────────────────────────────────────────────────────
function ListView({ onShowDetails }) {
  const [statusFilter, setStatusFilter] = useState("all");
  const [deptFilter, setDeptFilter] = useState("all");
  const [activePage, setActivePage] = useState(1);

  const STATUS_TABS = [
    {id:"all",label:"All",count:65},
    {id:"awaiting",label:"Awaiting Receipt",count:12},
    {id:"partial",label:"Partial",count:4},
    {id:"today",label:"Today",count:5},
    {id:"overdue",label:"Overdue",count:2,crit:true},
    {id:"received",label:"Received",count:47},
  ];

  const DEPT_CHIPS = [
    {id:"all",label:"All",count:18},
    {id:"Rooms",label:"Rooms",count:5,color:"var(--dept-rooms)"},
    {id:"F&B",label:"F&B",count:4,color:"var(--dept-fb)"},
    {id:"A&G",label:"A&G",count:2,color:"var(--dept-admin)"},
    {id:"IT",label:"IT",count:1,color:"var(--dept-sm)"},
    {id:"S&M",label:"S&M",count:1,color:"var(--dept-sales)"},
    {id:"R&M",label:"R&M",count:6,color:"var(--dept-eng)"},
  ];

  const visible = PO_ROWS.filter(r => {
    const s = statusFilter === "all" || r.status === statusFilter;
    const d = deptFilter === "all" || r.dept === deptFilter;
    return s && d;
  });

  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="title">Receiving</h1>
          <div className="title-sub">April 2026 &nbsp;·&nbsp; 18 POs in queue &nbsp;·&nbsp; DoubleTree by Hilton Orlando Airport</div>
        </div>
        <div className="head-actions">
          <button className="btn"><Icon.Download /><span>Export Report</span></button>
        </div>
      </div>

      {/* KPIs */}
      <div className="kpis">
        <div className="kpi hero">
          <div className="kpi-spark"><svg width={76} height={34} viewBox="0 0 76 34" fill="none"><path d="M2 26 L12 22 L20 24 L28 16 L36 18 L46 10 L54 12 L62 6 L74 8" stroke="#86b6ff" strokeWidth="1.6" strokeLinecap="round" fill="none"/><path d="M2 26 L12 22 L20 24 L28 16 L36 18 L46 10 L54 12 L62 6 L74 8 L74 34 L2 34 Z" fill="#86b6ff" opacity=".12"/></svg></div>
          <div className="kpi-label"><span className="kpi-dot" style={{background:"#7ce0a3"}}></span>Awaiting Receipt</div>
          <div className="kpi-num">12</div>
          <div className="kpi-sub">$48,217 expected value</div>
          <div className="kpi-bar"><div className="kpi-bar-fill" style={{width:"62%",background:"linear-gradient(90deg,#a5e0ff,#5a8bff)"}}></div></div>
          <div className="kpi-foot"><span>8 due this week</span><span className="kpi-trend up" style={{background:"rgba(124,224,163,.18)",color:"#7ce0a3"}}>+3 vs Mar</span></div>
        </div>
        <div className="kpi">
          <div className="kpi-spark"><svg width={76} height={34} viewBox="0 0 76 34" fill="none"><path d="M2 22 L14 18 L24 22 L36 16 L48 18 L60 12 L74 14" stroke="#cbd2da" strokeWidth="1.6" strokeLinecap="round" fill="none"/><path d="M2 22 L14 18 L24 22 L36 16 L48 18 L60 12 L74 14 L74 34 L2 34 Z" fill="#cbd2da" opacity=".12"/></svg></div>
          <div className="kpi-label"><span className="kpi-dot" style={{background:"var(--warn)"}}></span>Partial Deliveries</div>
          <div className="kpi-num" style={{color:"var(--warn)"}}>4</div>
          <div className="kpi-sub">awaiting remaining lines</div>
          <div className="kpi-bar"><div className="kpi-bar-fill" style={{width:"42%",background:"linear-gradient(90deg,#f5c26b,#e8920a)"}}></div></div>
          <div className="kpi-foot"><span>$6,840 remaining</span><span className="kpi-trend flat">42% complete</span></div>
        </div>
        <div className="kpi">
          <div className="kpi-spark"><svg width={76} height={34} viewBox="0 0 76 34" fill="none"><path d="M2 14 L14 18 L24 20 L36 22 L48 24 L60 26 L74 28" stroke="#cbd2da" strokeWidth="1.6" strokeLinecap="round" fill="none"/><path d="M2 14 L14 18 L24 20 L36 22 L48 24 L60 26 L74 28 L74 34 L2 34 Z" fill="#cbd2da" opacity=".12"/></svg></div>
          <div className="kpi-label"><span className="kpi-dot" style={{background:"var(--crit)"}}></span>Overdue</div>
          <div className="kpi-num" style={{color:"var(--crit)"}}>2</div>
          <div className="kpi-sub">past expected delivery</div>
          <div className="kpi-bar"><div className="kpi-bar-fill" style={{width:"18%",background:"linear-gradient(90deg,#f78080,#c93a3a)"}}></div></div>
          <div className="kpi-foot"><span>3+ days late</span><span className="kpi-trend down">Action needed</span></div>
        </div>
        <div className="kpi">
          <div className="kpi-spark"><svg width={76} height={34} viewBox="0 0 76 34" fill="none"><path d="M2 28 L14 24 L24 22 L36 18 L48 16 L60 12 L74 10" stroke="#cbd2da" strokeWidth="1.6" strokeLinecap="round" fill="none"/><path d="M2 28 L14 24 L24 22 L36 18 L48 16 L60 12 L74 10 L74 34 L2 34 Z" fill="#cbd2da" opacity=".12"/></svg></div>
          <div className="kpi-label"><span className="kpi-dot" style={{background:"var(--good)"}}></span>Received This Month</div>
          <div className="kpi-num">47</div>
          <div className="kpi-sub">$84,290 value</div>
          <div className="kpi-bar"><div className="kpi-bar-fill" style={{width:"78%",background:"linear-gradient(90deg,#76e2a2,#34a86b)"}}></div></div>
          <div className="kpi-foot"><span>1 over-received</span><span className="kpi-trend up">+12 vs Mar</span></div>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="tabs">
        {STATUS_TABS.map(t => (
          <button key={t.id} className={`tab-btn${statusFilter===t.id?" active":""}`} onClick={() => setStatusFilter(t.id)}>
            {t.label}
            <span className={`badge-count${t.crit?" crit":""}`}>{t.count}</span>
          </button>
        ))}
      </div>

      {/* Toolbar */}
      <div className="toolbar">
        <button className="month-btn"><Icon.Cal /> April 2026</button>
        <div className="chips">
          {DEPT_CHIPS.map(c => (
            <button key={c.id} className={`chip${deptFilter===c.id?" on":""}`} onClick={() => setDeptFilter(c.id)}>
              {c.color && <span className="dept-dot" style={{background:c.color}}></span>}
              {c.label} <span className="chip-ct">{c.count}</span>
            </button>
          ))}
        </div>
        <div className="spacer" />
        <select className="sel"><option>All vendors</option><option>Sysco Foods</option><option>HD Supply</option></select>
        <select className="sel"><option>Sort: Expected date ↑</option><option>Sort: PO amount</option><option>Sort: PO #</option></select>
      </div>

      {/* Table */}
      <div className="table-wrap">
        <table className="recv">
          <thead>
            <tr>
              <th>PO #</th><th>Vendor</th><th>Department</th>
              <th className="r">PO Amount</th><th>Expected</th>
              <th>Progress</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {visible.map(row => (
              <tr key={row.id} className="r-row" style={{opacity:row.opacity}} onClick={() => onShowDetails()}>
                <td className="po-num">
                  <span className="mono">{row.id}</span>
                  <span className="sub">{row.lines}</span>
                </td>
                <td className="vendor">{row.vendor}<span className="sub">{row.vendorSub}</span></td>
                <td>
                  <span className="dept-pill">
                    <span className="dept-dot" style={{background:row.deptColor}}></span>
                    {row.dept}
                  </span>
                </td>
                <td className="amt-td">{row.amount}<span className="sub">{row.linesRcv}</span></td>
                <td className={`date-td${row.dateCls?" "+row.dateCls:""}`}>
                  {row.expected}
                  <span className="sub">{row.expectedSub}</span>
                </td>
                <td style={{minWidth:160}}>
                  <div className="progress-wrap">
                    <div className="progress-text">
                      <span>{row.linesRcv.split(" ")[0]} / {row.linesRcv.split(" ")[2]?.replace("lines","")?.trim() || "?"} lines</span>
                      <span className="pct">{row.progress}%</span>
                    </div>
                    <ProgressBar pct={row.progress} type={row.progressType} />
                  </div>
                </td>
                <td><span className={`badge ${row.statusBadge}`}><span className="b-dot"></span>{row.statusLabel}</span></td>
                <td className="actions-td" onClick={e => { e.stopPropagation(); onShowDetails(); }}>
                  <button className="btn sm">Show Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pager */}
      <div style={{marginTop:4}}>
        <div className="pager">
          <div className="pager-left">Showing <b>10 of 127</b></div>
          <div className="pager-center">
            <div className="pages">
              <button className="p-btn arrow disabled"><Icon.ChevL /></button>
              {[1,2,"...",7,8,9].map((p,i) =>
                p === "..." ? <span key={i} className="ellipsis">...</span> :
                <button key={i} className={`p-btn${activePage===p?" active":""}`} onClick={()=>setActivePage(p)}>{p}</button>
              )}
              <button className="p-btn arrow"><Icon.ChevR /></button>
            </div>
          </div>
          <div className="pager-right">
            <span>Lines per page</span>
            <select className="sel" style={{height:30,fontSize:12}}><option>10</option><option>25</option><option>50</option></select>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Sidebar nav items ──────────────────────────────────────────────────────
const NAV_ITEMS = [
  { label:"Dashboard", icon:<svg viewBox="0 0 24 24" fill="none" width={16} height={16}><rect x="3" y="3" width="7" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="3" y="15" width="7" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.5"/></svg> },
  { label:"Purchase Orders", icon:<svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><rect x="9" y="3" width="6" height="4" rx="1" stroke="currentColor" strokeWidth="1.5"/><path d="M9 12h6M9 16h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg> },
  { label:"Receiving", active:true, icon:<svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M12 3v12m0 0l-4-4m4 4l4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M20 17v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg> },
  { label:"Invoices & Matching", icon:<svg viewBox="0 0 24 24" fill="none" width={16} height={16}><rect x="5" y="3" width="14" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M8 8h8M8 12h8M8 16h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg> },
  { label:"Vendors / Contracts", icon:<svg viewBox="0 0 24 24" fill="none" width={16} height={16}><rect x="3" y="4" width="8" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="13" y="4" width="8" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="3" y="13" width="8" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><rect x="13" y="13" width="8" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/></svg> },
];

// ── Root App ───────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState("list"); // "list" | "detail"

  return (
    <>
      <style>{css}</style>
      <div className="app">
        {/* Sidebar */}
        <aside className="side">
          <div className="brand">
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <div className="logo">H</div>
              <span className="brand-name">Hotel<b>OS</b></span>
            </div>
            <button className="collapse-btn"><Icon.CollapseL /></button>
          </div>

          <button className="nav-cta"><Icon.Plus /><span>New Purchase Order</span></button>

          <nav className="nav">
            {NAV_ITEMS.map(n => (
              <button key={n.label} className={`nav-item${n.active?" active":""}`}>
                {n.icon}<span>{n.label}</span>
              </button>
            ))}
          </nav>

          <div className="side-foot">
            <button className="nav-item">
              <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M4 7h10M18 7h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><path d="M4 12h4M12 12h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><path d="M4 17h12M20 17h0" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><circle cx="16" cy="7" r="2" stroke="currentColor" strokeWidth="1.5"/><circle cx="10" cy="12" r="2" stroke="currentColor" strokeWidth="1.5"/><circle cx="18" cy="17" r="2" stroke="currentColor" strokeWidth="1.5"/></svg>
              <span>Display Options</span>
            </button>
            <button className="nav-item">
              <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/><path d="M19.4 13.7a7.5 7.5 0 0 0 0-3.4l2-1.6-2-3.5-2.4.7a7.5 7.5 0 0 0-3-1.7L13.5 2h-3l-.5 2.2a7.5 7.5 0 0 0-3 1.7l-2.4-.7-2 3.5 2 1.6a7.5 7.5 0 0 0 0 3.4l-2 1.6 2 3.5 2.4-.7c.9.7 1.9 1.3 3 1.7l.5 2.2h3l.5-2.2c1.1-.4 2.1-1 3-1.7l2.4.7 2-3.5-2-1.6Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>
              <span>Account Settings</span>
            </button>
            <button className="nav-item">
              <svg viewBox="0 0 24 24" fill="none" width={16} height={16}><path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4M10 17l-5-5 5-5M5 12h12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
              <span>Log Out</span>
            </button>
          </div>
        </aside>

        {/* Main */}
        <main>
          <div className="topbar">
            <div className="crumb">Receiving <span style={{margin:"0 6px"}}>›</span> <b>{view==="list"?"Queue":"PO-2026-0436"}</b></div>
            <div className="search-wrap">
              <Icon.Search />
              <input placeholder="Search PO #, vendor, item…" />
            </div>
            <div className="top-actions">
              <button className="icon-btn"><Icon.Bell /></button>
              <div className="avatar">SK</div>
            </div>
          </div>

          <div className="page">
            {view === "list"
              ? <ListView onShowDetails={() => setView("detail")} />
              : <DetailView onBack={() => setView("list")} />
            }
          </div>
        </main>
      </div>
    </>
  );
}
